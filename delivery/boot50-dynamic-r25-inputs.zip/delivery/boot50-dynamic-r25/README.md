# Boot50 dynamic whole-board diagnostic input

This is a diagnostic synthesis/place/route input, **not a dynamic bitstream or frequency qualification**. The hardware boots CPU50/fabric50. Synthesis and every implementation stage retain CPU300/fabric250 timing requirements. Fixed MAC125, TIME/UI/debug250 and UART/AON50 are separate. Production operating-point tables remain empty, and signoff/bitstream entry points remain closed.

The current exact gate source passed one full software CPU50→100→50 and fabric50→100→50 behavioral platform loop, after same-binary startup smoke. The complete PHY initialization ran once. Actual Vivado component primitive validation is separate from this platform behavioral result. Whole-board mapped CDC, STA, route and DDR calibration are not yet established.

## Native Windows, fresh directory, no local Java/Mill needed

Run from the verified Git checkout containing this delivery. Select the actual published delivery commit, not an unrelated old SoC checkpoint. `$Vivado` and `$Python` must be the already verified native Windows executable paths. No tool install is needed.

```powershell
$Commit = (git rev-parse HEAD).Trim()
$Archive = 'E:\VM\Share\Valence-rtl\boot50-dynamic-r25-input.zip'
$Root = 'E:\VM\Share\Valence-rtl\boot50-dynamic-r25'
if ((Test-Path $Archive) -or (Test-Path $Root)) { throw 'Use fresh archive and directory; preserve earlier evidence.' }
# Both normal Git layouts are supported: a tracked directory, or one exact input ZIP.
$Packed = 'delivery/boot50-dynamic-r25-inputs.zip'
$Delivery = if (git ls-tree --name-only $Commit -- $Packed) { $Packed } else { 'delivery/boot50-dynamic-r25' }
git archive --format=zip --output=$Archive $Commit src/main/scala src/main/resources src/test/scala/platform fpga/common fpga/firmware fpga/zu15eg fpga/next fpga/inorder simulator/jtag scripts/cloud/env.sh $Delivery build.mill
if ($LASTEXITCODE -ne 0) { throw 'Source export failed.' }
Expand-Archive -LiteralPath $Archive -DestinationPath $Root
if ($Delivery -eq $Packed) {
  # The publisher verifies this archive SHA; extraction preserves canonical input bytes.
  Expand-Archive -LiteralPath (Join-Path $Root $Packed) -DestinationPath $Root
}
$Old = 'E:\VM\Share\Valence-rtl\valence-i1-optional-20261019-r1\performance300-independent-366a643-r3'
New-Item -ItemType Directory -Path (Join-Path $Root 'ip'), (Join-Path $Root 'evidence') | Out-Null
Copy-Item -LiteralPath (Join-Path $Old 'ip\ddr4_0.xci') -Destination (Join-Path $Root 'ip\ddr4_0.xci')
Copy-Item -LiteralPath (Join-Path $Old 'evidence\dci-result.json') -Destination (Join-Path $Root 'evidence\dci-result.json')
Push-Location $Root
try {
  & $Python fpga/common/diagnostic.py freeze --root . --delivery-commit $Commit --emission delivery/boot50-dynamic-r25/rtl/emission-profile.json --rom delivery/boot50-dynamic-r25/firmware/bootrom-128k.bin --coe delivery/boot50-dynamic-r25/firmware/bootrom.coe --firmware-contract delivery/boot50-dynamic-r25/firmware/clock-contract.json --mig ip/ddr4_0.xci --native-evidence evidence/dci-result.json --threads 8
  if ($LASTEXITCODE -ne 0) { throw 'Input freeze blocked; do not launch Vivado.' }
  & .\fpga\common\run-diagnostic.ps1 -Manifest (Join-Path $Root 'diagnostic.json') -Vivado $Vivado -Python $Python
} finally { Pop-Location }
```

The fresh directory is outside the Git worktree. No dirty-tree or aggregate-commit equality shortcut is used: `source_commit` records the actual `$Commit`, the production baseline stays separately identified, and all 973 source/input hashes are checked before native execution. The ZIP is a byte-preserving transport only.

The script imports the actual DDR4 XCI into an isolated project and generates new ROM/AON clock IP. It does **not** reuse an old SoC, old three-output Clock Wizard, or old ROM DCP. The exact unchanged two-source DCI component receipt is reused only for that component, never as old whole-profile acceptance. The XCI, receipt and board-pin hashes are checked.

The existing pipeline runs synthesis, mapped post-synthesis checks, optimization, placement, physical optimization and routing. Negative slack remains a measured failure, never a relaxed target. DRC/clock-coverage failures stop the stage. No `write_bitstream`, `write_device_image` or signoff phase is available.

## First mapped CDC closure is deliberately strict

The dynamic scopes cover the actual fixed125 MAC boundary, CSR, four37-bit streams, epoch/release/IRQ/fault CDC, runtime timer/DDR qualification, relocated debug boundary and 28 CPU-boundary FIFOs. They are source-reviewed scopes, **not yet mapped evidence**. Missing/pruned banks or changed implementation names stop post-checks. In that case preserve `raw-synthesized-unqualified.dcp`, its JSON provenance, the original manifest and all logs; inspect the same checkpoint and repair only reviewed mapped scopes. Do not rerun expensive synthesis to discover each next missing endpoint, invent an absent-bank waiver, cut functional reset paths or relax targets. The raw provenance also seals the three freshly generated OOC DCPs for exact-project recovery.

## Genuine common boot50 ROM

The unpadded `bootrom.bin` is the original builder output. `bootrom-128k.bin` is a separate zero-padded derivative; the COE is byte-checked against it. The original build contract is not relabeled. Feature selection remains boot menu, posted-RX netboot, JTAG download and slice2 CRC. The new explicit common profile keeps the existing CMU metadata macro and all MMIO/link/launch paths. Only the nominal fabric metadata changes to50; TIME/DDR UI remain250, UART divisor1/reference7372800/baud460800 remain unchanged.

Rebuild with the existing cross-toolchain and pinned official CoreMark dependency:

```sh
source scripts/cloud/env.sh
python3 fpga/firmware/setup_monitor_coremark.py --fetch
python3 fpga/firmware/build.py --boot-menu --netboot --netboot-posted-rx --jtag-download --crc-mode slice2 --ddr --ddr-bytes 0x80000000 --common-platform --common-clock-profile boot50-dynamic --cpu-hz 50000000 --fabric-hz 50000000 --timebase-hz 250000000 --ddr-ui-hz 250000000 --uart-reference-hz 7372800 --uart-baud 460800 --out build/fpga/boot50-rom
```

CMU resource1 nominalHz is boot metadata, not a frequency counter and not live applied-rate status. All firmware deadlines use fixed TIME250. This delivery does not claim Linux boot, a Linux payload, U-Boot, or board execution.
