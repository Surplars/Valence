# efficiency4＋W11/W14＋MUL capture 本地 Vivado 对比包

这个小包在已交付的主候选 efficiency4-candidate 上，仅打开
registeredMulLoadOperandCapture。原 W11 compact immediate、W14 banked indirect16、
efficiency4 CPU 和 Probe-Acquire 总线配置全部保留。原包没有改动。

## 本地直接运行

无需重新编译 Scala，本包已包含全部 292 个 SystemVerilog 模块。
安装 Python 3.10+，在 Vivado 命令行环境中运行：

```text
python rtl-candidate/run_local.py --verify-only
python rtl-candidate/run_local.py --out ../mul-candidate-run-01
```

如果找不到 Vivado，给命令补上 --vivado 和你安装的 vivado/vivado.bat 完整路径。
器件严格为 xczu15eg-ffvb1156-2-i；默认 CPU 10ns、fabric 4ns。
可用 --cpu-period NS --fabric-period NS 修改测试目标。输出目录必须不存在。

对照组用原大包的 **rtl/efficiency4-candidate/run_local.py**，不要用
rtl/efficiency4-baseline，否则会同时比较 W11/W14，不能只看新增 MUL 开关。
两次应使用同一 Vivado 版本、机器设置、CPU/fabric 周期和实现流程。

脚本只执行一次综合、优化、布局、物理优化、布线，保存每阶段 DCP 和报告。
请看 routed_timing_summary.rpt、routed_setup_paths.rpt、routed_hold_paths.rpt、
routed_utilization.rpt、routed_route_status.rpt、DRC/CDC 以及未约束路径。
COMPLETED 仅表示命令结束，不表示时序或 DRC 通过。

## 本次实测验证范围

- 全量 Scala 编译成功；6 个契约套件 27 项测试通过。
- 后端开启/关闭配对：22 个非 fault/IRQ 正例通过，2 个观察器负例按预期拒绝。
  当前公开 ABI、64 位 owner tag、操作数和 registered capture 相位已复核。
  模型全部 5 个 C++ 分片编译链接，使用 ASAN/UBSAN。
- 完整 CPU＋真实 CDC＋真实 fabric RTL 导出和有界模块闭包检查通过。
  新旧候选均为 292 个模块；新候选只改变 IntegerBackend.sv。
- 重新导出的对照 292 个 SV 文件与原包逐字节一致，配置也相同；
  ooc-identity 中只有编译出处不同，因为是本次新工作树重新编译。

没有运行 Vivado、当前整机 CoreMark/CPU＋fabric 工作负载、总线带宽测量或板级验证。
上述后端测试不等于完整 CPU/fabric 行为通过，也没有覆盖 fault/IRQ 或所有仲裁角落。
历史同开关的约 +0.83% CoreMark ROI 吞吐、+0.60% LUT 仅是历史单项结果，
不能作为这次组合的性能、面积或 Fmax 结论。实际时序/面积请以你的本地实现报告为准。

## 源码与证据

本包为了小而不重复原大包全部源码；source-delta/ 是相对原大包 source/ 的源码叠加。
如需重建：先复制原大包 source/ 到一个新目录，按 SOURCE-DELTA.json 的 before_sha256
核对四个 Scala 文件，再把 source-delta/ 中的文件按相同相对路径复制进去。
SOURCE-CHANGES.patch 提供这四个文件的可审阅差异；完整变化后的文件也都在。
不要直接叠到裸 e437ba2 上，因为原 W11/W14 集成应保留。
不需要修改原包，也不需要源码叠加才能运行本包已经导出的 RTL。

新工作树分支为 integration/mul-load-capture-20261108，修改尚未提交或推送。
源码重建应生成真实 compile receipt，再用 CombinedA1FabricTimingMain 的
新增模式 efficiency4-mul-candidate 导出。不能把云端 receipt 当作本地新编译证据。
当前契约测试、GSIM 命令和逐项日志、源码绑定和差异检查在 evidence/。
VALIDATION.json 汇总本次结果与未验证事项，MANIFEST.sha256.json 绑定全部文件。

## 边界

这是 OOC CPU＋真实总线候选，不是可直接上板的完整工程或 bitstream。
MIG、DDR 电气接口、PHY、板级时钟/复位/引脚等未包括，接口仍真实暴露。
CPU/fabric 跨域没有随意设 false path 或异步 clock-group 切断；外部 IO 延迟未指定。
因此必须区分核内路径、CDC 和未约束板级边界，不能把汇总 WNS 直接当作整板 Fmax。
详见 rtl-candidate/README.md。I1、H/V 及此前未接纳的实验没有混入。
