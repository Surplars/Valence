# 零新增流水级的 CPU / fabric 时序对照输入

这是针对 2026-11-08 MUL 候选实测长路径制作的实验对照包，不是时序已收敛的版本。
本轮没有运行 Vivado，没有更改频率约束，也没有新增 false path。
器件仍是 xczu15eg-ffvb1156-2-i，CPU 10 ns、fabric 4 ns。

## 两个目录

- baseline：同一次源码编译导出的原 MUL 候选功能配置。
- candidate：只启用下面两项零拍组合结构变化。每个目录均为独立、可校验、可运行的 RTL-only 输入，不需要安装 Scala / Mill。

1. CPU：三个内存地址供应加法器由手工八位分块进位选择改为原生 64 位加法，保持模 2^64 结果不变，让 FPGA 工具推断专用进位链。
2. fabric：两个请求入口各自提前计算窗口和长度合法性，再用与地址/size 完全相同的仲裁选择该布尔值，避免选完地址后再重复完整 65 位加法/比较。接受、owner、RAW/WAR、返回和配额均不变。

两个被拒绝的加拍探索没有进入本包 RTL：独立 manager 队列会破坏排队旧写的 RAW 次序；CPU 建议地址加拍使独立 load 周期增加 34.3%。
已检查两个目录均没有 ManagerRequestBoundary 或 RegisteredLoadProofLookahead 模块。

## 已验证的结果

- 13 个相关 Scala 配置检查通过。
- GSIM 算术独立 oracle：332,881 组输入通过。
- 独立组合等价证明：64 个结果位全部证明，无未证明位。
- CPU 后端 14 个 workload 的两版输出逐字节相同；4 个观察变异负控按预期失败。
  - 96 个独立虚拟 load：210 / 210 拍。
  - 64 个依赖 load：555 / 555 拍。
  - 96 个拥塞 load：735 / 735 拍。
- fabric：740,064 个任意偏移、超长和地址溢出检查通过。
- 双 manager 23,361 拍对照：全部接口、166 个保留状态字段、64 个 payload 数据字逐拍相同；6 个负控按预期失败。
  - 192 个混合 owner：6759 / 6759 拍。
  - 128 个连续 line read：1031 / 1031 拍。
  - 128 个串行依赖读：1570 / 1570 拍。
  - 被入口队列破坏的 accepted-order RAW/WAR 反例，两版原生 manager 均通过。
- 没有新增状态、流水延迟、请求容量或 PRF 读端口。

## 能说明和不能说明什么

相同组合映射中，单个“64 位左操作数 + 符号扩展 32 位立即数”加法器：
LUT 134→64，CARRY4 37→16，FF 0→0。这是 Yosys 的孤立组合映射，不是 Vivado 或整核面积。
GSIM 组合依赖节点数：CPU 126→116；fabric slot-WE 26→23。
这些数不是 LUT 级数或纳秒，不能替代用户报告中的 40 / 46 级路径，也不能预测 Fmax。

仍然存在上游仲裁、owner/ready 选择、fabric span/hazard 算术和布线成本。
尚未验证整核 LUT、实际布局布线 WNS、100/250 MHz、功耗、板级表现或完整 CPU CoreMark。
后端短测不等于整核/整 SoC 性能结论。

## 本地运行

仅校验文件，不启动 Vivado：

    python baseline\run_local.py --verify-only
    python candidate\run_local.py --verify-only

需要做配对本地实现时，使用相同 Vivado 版本、同一器件、同一时钟约束和两个全新的输出目录：

    python baseline\run_local.py --vivado "E:\Xilinx\2025.2\Vivado\bin\vivado.BAT" --out "D:\surplars\Downloads\zero-latency-baseline-01"
    python candidate\run_local.py --vivado "E:\Xilinx\2025.2\Vivado\bin\vivado.BAT" --out "D:\surplars\Downloads\zero-latency-candidate-01"

示例路径沿用上传报告中的安装位置；如果本机位置不同，请替换。
脚本不会覆盖已有结果，不生成 bitstream。已有脚本和约束原样保留。
本包的 baseline 是新导出的同源对照，不能只把 candidate 与先前一次布局布线的结果相减当作严格配对。

## 证据

`evidence/` 保留机器可读结果和原始测试输出；`EMITTED-TOPOLOGY.json` 明确记录 fabric 侧端口和 CPU 配置选择。
两个子包的 package.json 分别绑定其所有 RTL / Tcl / Python 文件；最外层 MANIFEST.sha256.json 绑定完整交付内容。
