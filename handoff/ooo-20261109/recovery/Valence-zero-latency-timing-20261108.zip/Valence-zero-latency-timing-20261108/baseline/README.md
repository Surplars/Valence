See ../README-先读我.md for this matched experiment, evidence and limitations.
This subpackage contains baseline RTL. No Vivado run has been performed for this export.
