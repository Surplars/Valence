package soc.core.ooo

import chisel3._
import chisel3.util._
import soc.bus.tilelink.{TLBundle, TLParams}

/** Independent capacities: changing miss slots never changes cache geometry or LSU width. */
case class CoherentCacheConcurrency(readMshrs: Int = 1, responseEntries: Int = 2, writebackEntries: Int = 1,
    overlapWritebackRefill: Boolean = false, nextLinePrefetch: Boolean = false, prefetchCandidateCycles: Int = 1,
    prefetchBreakOnStore: Boolean = false, storeNextLinePrefetch: Boolean = false, storePrefetchMruInsertion: Boolean = false,
    postedPrefetchCoexistence: Boolean = false, storePrefetchLruVictim: Boolean = false,
    distinctWayRelease: Boolean = false, independentDemandAdmission: Boolean = false,
    splitPrefetchTracking: Boolean = false, readPrefetchDirtyRetry: Boolean = false,
    readPrefetchDemandAdoption: Boolean = false, readPrefetchStoreHold: Boolean = false,
    durableReadPrefetchCandidate: Boolean = false, readPrefetchBehindStore: Boolean = false,
    internalLineGrant: Boolean = false, concurrentReadStorePrefetch: Boolean = false,
    memoryScheduleOverlap: Boolean = false, futureHomeWayReservation: Boolean = false) {
    require(!futureHomeWayReservation || memoryScheduleOverlap,
        "future Home way reservation requires memory scheduling overlap")
    require(!memoryScheduleOverlap || (readMshrs == 2 && responseEntries == 2 && writebackEntries == 2 &&
        overlapWritebackRefill && independentDemandAdmission),
        "memory scheduling overlap preserves the reviewed two-owner independent cache")
    require(!internalLineGrant || (readMshrs == 2 && writebackEntries == 2 && overlapWritebackRefill),
        "whole Grant transport requires the reviewed bounded mixed Home/cache")
    require(!concurrentReadStorePrefetch || (readMshrs == 2 && writebackEntries == 2 &&
        independentDemandAdmission && durableReadPrefetchCandidate),
        "read/store PF coexistence requires existing two-MSHR/two-WB independent/durable owners")
    require(!independentDemandAdmission || readMshrs >= 2,
        "independent demand admission reuses the existing nonblocking miss owners")
    require(Set(1, 2, 4).contains(readMshrs))
    require(prefetchCandidateCycles >= 1 && prefetchCandidateCycles <= 32,
        "prefetch candidate lifetime must be in 1..32 allocation attempts")
    require(prefetchCandidateCycles == 1 || nextLinePrefetch,
        "retained prefetch candidates require next-line prefetch")
    require(!readPrefetchStoreHold || (nextLinePrefetch && prefetchCandidateCycles > 1),
        "read prefetch store hold requires next-line prefetch and an existing multi-cycle candidate")
    require(!durableReadPrefetchCandidate || (prefetchCandidateCycles == 16 && readMshrs == 2 &&
        writebackEntries == 2 && splitPrefetchTracking && readPrefetchDirtyRetry &&
        readPrefetchDemandAdoption && readPrefetchStoreHold),
        "durable read candidates require the reviewed 16-attempt two-MSHR/two-WB split retry/adoption/store-hold profile")
    require(!readPrefetchBehindStore || durableReadPrefetchCandidate,
        "read prefetch capture behind a store owner requires durable read candidates")
    require(!prefetchBreakOnStore || nextLinePrefetch,
        "store-sensitive prediction history requires next-line prefetch")
    require(!storeNextLinePrefetch || nextLinePrefetch,
        "checked store prediction requires next-line prefetch")
    require(!splitPrefetchTracking || (nextLinePrefetch && storeNextLinePrefetch),
        "split prefetch tracking requires next-line and checked store prefetch")
    require(!readPrefetchDemandAdoption || (splitPrefetchTracking && independentDemandAdmission &&
        readMshrs >= 2 && writebackEntries >= 2 && overlapWritebackRefill),
        "read prefetch demand adoption requires split tracking, independent admission and existing overlapping owners")
    require(!readPrefetchDirtyRetry || splitPrefetchTracking,
        "read prefetch dirty retry requires split read/store resident tracking")
    require(!storePrefetchMruInsertion || storeNextLinePrefetch,
        "store-origin MRU insertion requires checked store prefetch")
    require(!storePrefetchLruVictim || storeNextLinePrefetch,
        "store-origin LRU victim selection requires checked store prefetch")
    require(!distinctWayRelease || (readMshrs == 2 && writebackEntries == 2 &&
        overlapWritebackRefill && storeNextLinePrefetch),
        "distinct-way release requires the two-MSHR/two-WB checked-store-prefetch profile")
    require(!postedPrefetchCoexistence || (nextLinePrefetch && readMshrs == 2),
        "posted/prefetch coexistence requires the original two-MSHR prefetch cache")
    require(!nextLinePrefetch || readMshrs >= 2, "data prefetch reuses a second miss slot")
    require(responseEntries >= readMshrs && responseEntries >= 2 && responseEntries <= 16 &&
        (responseEntries & (responseEntries - 1)) == 0)
    require(Set(1, 2, 4).contains(writebackEntries))
    require(readMshrs > 1 || writebackEntries == 1, "legacy cache has one release owner")
    require(!overlapWritebackRefill || (readMshrs > 1 && writebackEntries >= 2))
    val acquireEntries: Int = math.max(2, readMshrs)
    val releaseSource: Int = acquireEntries
    val sourceBits: Int = log2Ceil(acquireEntries + writebackEntries)
    val sinkBits: Int = math.max(1, log2Ceil(readMshrs))
}

class DataPrefetchEvents extends Bundle {
    val candidate = Bool()
    val allocated = Bool()
    val useful = Bool()
    val error = Bool()
    val missOwners = UInt(3.W)
    val releaseOwners = UInt(3.W)
}

class CoherentLineCachePort(params: TLParams, postedConfig: Option[PostedStoreMergeConfig] = None,
    returnConfig: Option[CpuReturnConfig] = None, internalLineGrant: Boolean = false) extends Bundle {
    val posted = postedConfig.map(c => new PostedStoreCachePort(c))
    val upstream = Flipped(new DataPort(returnConfig.map(_.handleBits).getOrElse(0)))
    val downstream = new DataPort
    val tl = new TLBundle(params)
    val lineGrant = if (internalLineGrant) Some(Flipped(Decoupled(new soc.ip.tilelink.LineGrant(params)))) else None
    val flushRequest = Input(Bool())
    val flushDone = Output(Bool())
    val prefetchBusy = Output(Bool())
    val prefetch = Output(new DataPrefetchEvents)
    val hit = Output(Bool())
    val miss = Output(Bool())
    val profile = Output(new CoherentCacheProfile)
}

abstract class CoherentLineCacheModule(params: TLParams, postedConfig: Option[PostedStoreMergeConfig] = None,
    returnConfig: Option[CpuReturnConfig] = None, internalLineGrant: Boolean = false) extends Module {
    val io = IO(new CoherentLineCachePort(params, postedConfig, returnConfig, internalLineGrant))
    io.prefetch := 0.U.asTypeOf(new DataPrefetchEvents)
}

object CoherentLineCacheModule {
    /** Caller selects capacities explicitly; the reference implementation stays available unchanged. */
    def build(base: BigInt, bytes: BigInt, lines: Int, params: TLParams, ways: Int,
        concurrency: CoherentCacheConcurrency, tagConfig: CacheTagConfig = CacheTagConfig.FullWidth,
        postedConfig: Option[PostedStoreMergeConfig] = None,
        returnConfig: Option[CpuReturnConfig] = None, registerProbeLookup: Boolean = false,
        localReadSelection: Boolean = false,
        allowSharedFutureLruWriteData: Boolean = false,
        disjointEvictionStoreOverlap: Boolean = false): CoherentLineCacheModule = {
        require(!disjointEvictionStoreOverlap || concurrency.readMshrs > 1,
            "disjoint eviction/store overlap requires the nonblocking cache constructor")
        require(!localReadSelection || concurrency.readMshrs > 1,
            "local read selection requires the nonblocking cache constructor")
        require(!registerProbeLookup || concurrency.readMshrs > 1,
            "registered probe lookup requires the nonblocking cache constructor")
        require(returnConfig.isEmpty || (concurrency.readMshrs == 2 && concurrency.responseEntries == 2),
            "tagged CPU store returns retain the reviewed two-MSHR/two-response cache")
        require(!concurrency.postedPrefetchCoexistence || postedConfig.exists(_.enabled),
            "posted/prefetch coexistence requires an enabled posted owner")
        postedConfig.foreach(c => require(c.enabled && concurrency.readMshrs == 2,
            "posted integration requires explicit ON and original two-MSHR cache"))
        // Keep the new write-data representation confined to the reviewed board domain.
        // The tagged-return and full-aperture integration is checked by the combined CPU gate.
        val reviewedWriteDataConcurrency = CoherentCacheConcurrency(
            readMshrs = 2, responseEntries = 2, writebackEntries = 2,
            overlapWritebackRefill = true, nextLinePrefetch = true, prefetchCandidateCycles = 16,
            storeNextLinePrefetch = true, storePrefetchMruInsertion = true,
            postedPrefetchCoexistence = true, independentDemandAdmission = true,
            splitPrefetchTracking = true, readPrefetchDirtyRetry = true,
            readPrefetchDemandAdoption = true, readPrefetchStoreHold = true,
            durableReadPrefetchCandidate = true, readPrefetchBehindStore = true,
            internalLineGrant = true, concurrentReadStorePrefetch = true, memoryScheduleOverlap = true)
        val qualifiedSharedWriteData = base == BoardSocConfig.ramBase && bytes == BigInt(2) * 1024 * 1024 * 1024 &&
            lines == 512 && ways == 2 &&
            (concurrency == reviewedWriteDataConcurrency ||
                (allowSharedFutureLruWriteData && concurrency.futureHomeWayReservation &&
                    concurrency.storePrefetchLruVictim &&
                    concurrency.copy(futureHomeWayReservation = false, storePrefetchLruVictim = false) ==
                        reviewedWriteDataConcurrency)) && tagConfig.compact && tagConfig.bankedStorage &&
            params.addrWidth == 64 && params.dataWidth == 64 && params.sourceBits == 3 && params.sinkBits == 1 &&
            registerProbeLookup && localReadSelection &&
            postedConfig.exists(c => c.enabled && c.tokenTagBits == 64 && c.tokenIndexBits == 4 &&
                c.generationBits == 64 && c.epochBits == 32 && c.cacheSets == 256 && c.cacheWays == 2 &&
                c.readMshrs == 2 && c.responseEntries == 2 && c.writebackEntries == 2 &&
                c.guaranteedBase == base && c.guaranteedBytes == bytes) &&
            returnConfig.contains(CpuReturnConfig(4, 2, true))
        if (concurrency.readMshrs == 1) Module(new CoherentLineCache(base, bytes, lines, params, ways, concurrency.responseEntries, tagConfig))
        else Module(new NonBlockingCoherentLineCache(base, bytes, lines, params, ways, concurrency, tagConfig,
            postedConfig, returnConfig, registerProbeLookup, localReadSelection,
            shareStoreWriteData = qualifiedSharedWriteData,
            disjointEvictionStoreOverlap = disjointEvictionStoreOverlap))
    }
}
