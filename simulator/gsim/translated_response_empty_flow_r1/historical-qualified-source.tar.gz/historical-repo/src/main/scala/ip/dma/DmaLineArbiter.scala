package soc.ip.dma

import chisel3._
import chisel3.util._

/** Two fair line masters sharing one global tag pool, without buffering line payloads.
  *
  * The upstream Decoupled stability contract retains the selected payload while an
  * offer is stalled. Only its master and global tag are locked here. Responses may
  * return in any order; each global tag stays owned through response handshake.
  * A response cannot bypass the registered owner table, even for a zero-cycle
  * responder (which must retain its response until this arbiter asserts ready).
  * Reset is a coordinated cold reset: it clears owners and held reservations, and
  * must not be used as a hot abort of accepted or externally held transactions.
  */
class DmaLineArbiter(entries: Int = 1) extends Module {
    require(Set(1, 2, 4, 8).contains(entries))
    private val tagBits = math.max(1, log2Ceil(entries))
    val io = IO(new Bundle {
        val clients = Vec(2, Flipped(new DmaLinePort(entries)))
        val memory = new DmaLinePort(entries)
    })

    val live = RegInit(VecInit(Seq.fill(entries)(false.B)))
    val owner = Reg(Vec(entries, Bool()))
    val localTag = Reg(Vec(entries, UInt(tagBits.W)))
    val turn = RegInit(false.B)
    val held = RegInit(false.B)
    val heldOwner = Reg(Bool())
    val heldTag = Reg(UInt(tagBits.W))

    val free = VecInit(live.map(v => !v))
    val freeAvailable = free.asUInt.orR
    val freeTag = PriorityEncoder(free.asUInt).pad(tagBits)
    // VALID alone does not claim a local tag. A producer may offer reuse while
    // the previous transaction drains; select other eligible work meanwhile.
    val localAvailable = VecInit((0 until 2).map { master =>
        !VecInit((0 until entries).map { slot =>
            live(slot) && owner(slot) === master.U && localTag(slot) === io.clients(master).request.bits.tag
        }).asUInt.orR
    })
    val eligible = VecInit((0 until 2).map(i => io.clients(i).request.valid && localAvailable(i)))
    val bothOffered = eligible(0) && eligible(1)
    val selected = Mux(held, heldOwner, Mux(bothOffered, turn, eligible(1)))
    val globalTag = Mux(held, heldTag, freeTag)
    val selectedRequest = Mux(selected, io.clients(1).request.bits, io.clients(0).request.bits)
    val selectedValid = Mux(selected, io.clients(1).request.valid, io.clients(0).request.valid)
    val selectedLocalAvailable = Mux(selected, localAvailable(1), localAvailable(0))
    val offerAvailable = (held || freeAvailable) && selectedLocalAvailable

    io.memory.request.valid := selectedValid && offerAvailable
    io.memory.request.bits := selectedRequest
    io.memory.request.bits.tag := globalTag
    for (i <- 0 until 2) {
        io.clients(i).request.ready := selected === i.U && offerAvailable && io.memory.request.ready
    }

    // A held reservation is not yet an accepted owner. No other allocation can
    // occur while held, so its free tag remains reserved without a second bitmap.
    when(io.memory.request.valid && !io.memory.request.ready) {
        held := true.B
        heldOwner := selected
        heldTag := globalTag
    }
    when(io.memory.request.fire) {
        held := false.B
        turn := !selected
    }

    val responseTag = io.memory.response.bits.tag
    val responseInRange = responseTag < entries.U
    val responseOwned = responseInRange && live(responseTag)
    val responseOwner = owner(responseTag)
    for (i <- 0 until 2) {
        io.clients(i).response.valid := io.memory.response.valid && responseOwned && responseOwner === i.U
        io.clients(i).response.bits := io.memory.response.bits
        io.clients(i).response.bits.tag := localTag(responseTag)
    }
    io.memory.response.ready := responseOwned &&
        Mux(responseOwner, io.clients(1).response.ready, io.clients(0).response.ready)

    // Allocation consults only the current live bitmap, never same-edge retirement.
    // Hence a full pool incurs one cycle before a newly retired tag can be offered.
    for (i <- 0 until entries) {
        val allocating = io.memory.request.fire && globalTag === i.U
        val retiring = io.memory.response.fire && responseTag === i.U
        when(retiring) { live(i) := false.B }
        when(allocating) {
            live(i) := true.B
            owner(i) := selected
            localTag(i) := selectedRequest.tag
        }
        assert(!(allocating && retiring), "DMA line tag cannot retire and be reallocated on the same edge")
        when(live(i)) {
            assert(localTag(i) < entries.U, "DMA line owner retained an out-of-range local tag")
        }
        for (j <- 0 until i) {
            assert(!(live(i) && live(j) && owner(i) === owner(j) && localTag(i) === localTag(j)),
                "DMA line master has duplicate live local tags")
        }
    }

    assert(PopCount(live) +& held.asUInt <= entries.U, "DMA line owners and held reservation exceed shared capacity")
    when(held) {
        assert(selectedLocalAvailable, "DMA line held offer lost its local tag reservation")
        assert(heldTag < entries.U && !live(heldTag), "DMA line held reservation lost its free global tag")
        assert(selectedValid, "DMA line master withdrew a held offer")
    }
    when(io.memory.request.valid) {
        assert(globalTag < entries.U && !live(globalTag), "DMA line offer must use a free global tag")
        assert(selectedRequest.tag < entries.U, "DMA line offered local tag is out of range")
    }
    when(io.memory.request.fire) {
        for (i <- 0 until entries) {
            assert(!(live(i) && owner(i) === selected && localTag(i) === selectedRequest.tag),
                "DMA line master reused a local tag before response retirement")
        }
    }
    when(io.memory.response.valid) {
        assert(responseInRange, "DMA line response tag is out of range")
        // Permit an immediate responder to expose VALID on the acceptance cycle,
        // but do not consume it until the registered ownership exists next cycle.
        val acceptingResponseOwner = io.memory.request.fire && globalTag === responseTag
        assert(responseOwned || acceptingResponseOwner, "DMA line response has no accepted owner")
    }
    when(io.memory.response.fire) {
        assert(responseOwned, "DMA line response retired without a registered owner")
    }

    // These history registers feed assertions only, never the payload datapath.
    // Synthesis that strips assertions removes their cone; there is no payload FIFO.
    def assertStableOffer(port: DecoupledIO[DmaLineRequest]): Unit = {
        val stalled = RegNext(port.valid && !port.ready, false.B)
        val previous = RegEnable(port.bits.asUInt, port.valid)
        when(stalled) {
            assert(port.valid, "DMA line stalled request lost valid")
            assert(port.bits.asUInt === previous, "DMA line stalled request payload or tag changed")
        }
    }
    for (i <- 0 until 2) { assertStableOffer(io.clients(i).request) }
    assertStableOffer(io.memory.request)
}
