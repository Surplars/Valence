package soc.ip.dma

import chisel3._
import chisel3.util._
import soc.ip.bus.{RegisterArbiter, RegisterPort, RegisterResponse}

class EthernetAxisWord extends Bundle {
    val data = UInt(32.W)
    val keep = UInt(4.W)
    val last = Bool()
}

/** Simple, full-duplex store-and-forward DMA; NOT AXI DMA register/SG compatible.
  * Legacy single descriptors plus a bounded opt-in posted RX ownership queue.
  * Ordered memory credits remain independent of packet queue capacity.
  * 64-bit aligned buffers, arbitrary byte lengths <= maxFrameBytes. Frames are
  * staged in synchronous RAM before transmission / before any RX memory write.
  * RX data and six-word PG138 status can arrive in either relative order.
  * All ports here are single-clock: a wrapper must cross ALL four MAC streams.
  */
class EthernetPacketDma(base: BigInt = BigInt("10002000", 16),
    ramBase: BigInt = BigInt("80200000", 16), ramBytes: BigInt = BigInt(512) * 1024 * 1024,
    maxFrameBytes: Int = 2048, postedRxSlots: Int = 4, memoryCredits: Int = 4, postedTxSlots: Int = 0,
    rxWritePrefetch: Boolean = false, rxLineWrites: Boolean = false, rxLineEntries: Int = 4) extends Module {
    require(base >= 0 && base % 256 == 0 && base + 256 <= (BigInt(1) << 64))
    require(ramBase >= 0 && ramBase % 8 == 0 && ramBytes >= maxFrameBytes && ramBytes % 8 == 0 &&
        ramBase + ramBytes <= (BigInt(1) << 64))
    require(maxFrameBytes >= 64 && maxFrameBytes <= 16384 && isPow2(maxFrameBytes))
    require(postedRxSlots >= 1 && postedRxSlots <= 16 && isPow2(postedRxSlots))
    require(postedTxSlots == 0 || (postedTxSlots >= 1 && postedTxSlots <= 16 && isPow2(postedTxSlots)))
    require(memoryCredits >= 1 && memoryCredits <= 16 && isPow2(memoryCredits))
    require(Set(1, 2, 4, 8).contains(rxLineEntries))
    val io = IO(new Bundle {
        val control = Flipped(new RegisterPort)
        val memory = new RegisterPort
        val rxLine = if (rxLineWrites) Some(new DmaLinePort(rxLineEntries)) else None
        val txData = Decoupled(new EthernetAxisWord)
        val txControl = Decoupled(new EthernetAxisWord)
        val rxData = Flipped(Decoupled(new EthernetAxisWord))
        val rxStatus = Flipped(Decoupled(new EthernetAxisWord))
        val irq = Output(Bool())
        val active = Output(Bool())
    })
    private val words = maxFrameBytes / 8
    private val indexBits = log2Ceil(words)
    private val countBits = indexBits + 1
    val arbiter = Module(new RegisterArbiter(memoryCredits))
    io.memory <> arbiter.io.memory
    val tx = arbiter.io.clients(0)
    val rx = arbiter.io.clients(1)
    val txBuffer = SyncReadMem(words, UInt(64.W))
    val rxBuffer = SyncReadMem(words, UInt(64.W))
    val irqEnable = RegInit(0.U(2.W))
    val txAddress = RegInit(0.U(64.W))
    val txLength = RegInit(0.U(64.W))
    val rxAddress = RegInit(0.U(64.W))
    val rxCapacity = RegInit(0.U(64.W))
    // Posted RX ABI is additive; disabled at reset for existing Linux drivers.
    // A slot remains owned from POST through completion POP, so retained
    // completions can never be overwritten by new submissions.
    private val rxSlots = postedRxSlots
    private val slotBits = log2Ceil(rxSlots).max(1)
    private val ownerBits = log2Ceil(rxSlots + 1)
    private val queuedAddressBits = (ramBase + ramBytes - 1).bitLength.max(3)
    private val queuedCapacityBits = log2Ceil(maxFrameBytes + 1)
    val queueEnabled = RegInit(false.B)
    val queueStopped = RegInit(false.B)
    val postAddress = RegInit(0.U(64.W))
    val postCapacity = RegInit(0.U(64.W))
    val slotOwned = RegInit(VecInit(Seq.fill(rxSlots)(false.B)))
    // POST validation proves bounded, eight-byte-aligned physical addresses.
    // Retain only their significant word bits; the MMIO ABI remains full64.
    val queuedAddressWords = Reg(Vec(rxSlots, UInt((queuedAddressBits - 3).W)))
    val queuedAddress = Wire(Vec(rxSlots, UInt(queuedAddressBits.W)))
    for (i <- 0 until rxSlots) { queuedAddress(i) := Cat(queuedAddressWords(i), 0.U(3.W)) }
    val queuedCapacity = Reg(Vec(rxSlots, UInt(queuedCapacityBits.W)))
    val completedMetadata = Reg(Vec(rxSlots, UInt(17.W)))
    val postIndex = RegInit(0.U(slotBits.W))
    val launchIndex = RegInit(0.U(slotBits.W))
    val completionIndex = RegInit(0.U(slotBits.W))
    val activeIndex = Reg(UInt(slotBits.W))
    val queueActive = RegInit(false.B)
    val ownedCount = RegInit(0.U(ownerBits.W))
    val pendingCount = RegInit(0.U(ownerBits.W))
    val completedCount = RegInit(0.U(ownerBits.W))
    val post = WireDefault(false.B)
    val consumePending = WireDefault(false.B)
    val complete = WireDefault(false.B)
    val pop = WireDefault(false.B)
    when(post =/= pop) { ownedCount := Mux(post, ownedCount + 1.U, ownedCount - 1.U) }
    when(post =/= consumePending) {
        pendingCount := Mux(post, pendingCount + 1.U, pendingCount - 1.U)
    }
    when(complete =/= pop) {
        completedCount := Mux(complete, completedCount + 1.U, completedCount - 1.U)
    }
    val txDone = RegInit(false.B)
    val txFailed = RegInit(false.B)
    val rxDone = RegInit(false.B)
    val rxFailed = RegInit(false.B)
    val txIdle :: txFill :: txControlState :: txLoad :: txWait :: txEmit :: Nil = Enum(6)
    val txState = RegInit(txIdle)
    val rxIdle :: rxCollect :: rxLoad :: rxWait :: rxOffer :: rxDrain :: Nil = Enum(6)
    val rxState = RegInit(rxIdle)
    val txQueue = if (postedTxSlots > 0) Some(Module(new EthernetTxDescriptorQueue(
        postedTxSlots, ramBase, ramBytes, maxFrameBytes))) else None
    val txQueueEnabled = txQueue.map(_.io.enabled).getOrElse(false.B)
    val txBusy = txState =/= txIdle
    val rxBusy = rxState =/= rxIdle
    io.active := txQueue.map(_.io.work).getOrElse(false.B) || txBusy || rxBusy || queueActive || (queueEnabled && pendingCount =/= 0.U)
    io.irq := (irqEnable(0) && Mux(txQueueEnabled, txQueue.map(_.io.irq).getOrElse(false.B), txDone)) || (irqEnable(1) && Mux(queueEnabled, completedCount =/= 0.U, rxDone))

    // TX prefetch: errors drain accepted/held reads; no partial frame reaches MAC.
    val txSent = RegInit(0.U(countBits.W))
    val txReceived = RegInit(0.U(countBits.W))
    val txLocked = RegInit(false.B)
    // Both descriptor launch paths validate length before the first read.
    // Capture the bounded count on that same edge; no request stage is added.
    val txWordCount = RegInit(0.U(countBits.W))
    def roundedTxWords(length: UInt): UInt = ((length +& 7.U) >> 3)(countBits - 1, 0)
    tx.request.valid := txState === txFill && (txLocked || !txFailed) &&
        txSent < txWordCount && txSent - txReceived < memoryCredits.U
    tx.request.bits.address := txAddress + (txSent << 3)
    tx.request.bits.write := false.B
    tx.request.bits.size := 3.U
    tx.request.bits.data := 0.U
    tx.request.bits.byteEnable := 255.U
    tx.response.ready := txState === txFill
    when(tx.request.valid && !tx.request.ready) { txLocked := true.B }
    when(tx.request.fire) { txSent := txSent + 1.U; txLocked := false.B }
    when(tx.response.fire) {
        txBuffer.write(txReceived(indexBits - 1, 0), tx.response.bits.data)
        txReceived := txReceived + 1.U
        when(tx.response.bits.error) { txFailed := true.B }
    }
    val controlIndex = RegInit(0.U(3.W))
    io.txControl.valid := txState === txControlState
    io.txControl.bits.data := Mux(controlIndex === 0.U, "ha0000000".U, 0.U)
    io.txControl.bits.keep := 15.U
    io.txControl.bits.last := controlIndex === 5.U
    when(txState === txFill && !txLocked && txReceived === txSent &&
        (txFailed || txReceived === txWordCount)) {
        when(txFailed) { txState := txIdle; txDone := true.B }
            .otherwise { txState := txControlState; controlIndex := 0.U }
    }
    val txIndex = RegInit(0.U(indexBits.W))
    val txBytes = RegInit(0.U(log2Ceil(maxFrameBytes + 1).W))
    val txUpper = RegInit(false.B)
    val txWord = Reg(UInt(64.W))
    val txRead = txBuffer.read(txIndex, txState === txLoad)
    when(io.txControl.fire) {
        when(controlIndex === 5.U) {
            txState := txLoad; txIndex := 0.U; txBytes := 0.U; txUpper := false.B
        }.otherwise { controlIndex := controlIndex + 1.U }
    }
    when(txState === txLoad) { txState := txWait }
    when(txState === txWait) { txWord := txRead; txState := txEmit }
    val txRemaining = txLength - txBytes
    io.txData.valid := txState === txEmit
    io.txData.bits.data := Mux(txUpper, txWord(63, 32), txWord(31, 0))
    io.txData.bits.keep := Mux(txRemaining >= 4.U, 15.U,
        ((1.U(5.W) << txRemaining(1, 0)) - 1.U)(3, 0))
    io.txData.bits.last := txRemaining <= 4.U
    when(io.txData.fire) {
        txBytes := txBytes + 4.U
        when(io.txData.bits.last) { txState := txIdle; txDone := true.B }
            .elsewhen(!txUpper) { txUpper := true.B }
            .otherwise { txUpper := false.B; txIndex := txIndex + 1.U; txState := txLoad }
    }

    // RX is independently armed. Never consume the next frame before software
    // acknowledges completion and installs a buffer. Malformed frames are drained.
    val rxBytes = RegInit(0.U(17.W))
    val rxDataDone = RegInit(false.B)
    val rxStatusDone = RegInit(false.B)
    val rxStatusIndex = RegInit(0.U(3.W))
    val statusWords = RegInit(VecInit(Seq.fill(6)(0.U(32.W))))
    val rxLow = Reg(UInt(32.W))
    val rxUpper = RegInit(false.B)
    val rxCaptureIndex = RegInit(0.U(indexBits.W))
    io.rxData.ready := rxState === rxCollect && !rxDataDone
    io.rxStatus.ready := rxState === rxCollect && !rxStatusDone
    val keep = io.rxData.bits.keep
    val keepLegal = keep === 1.U || keep === 3.U || keep === 7.U || keep === 15.U
    val rxNextBytes = rxBytes +& PopCount(keep)
    when(io.rxData.fire) {
        rxBytes := Mux(rxNextBytes > 65535.U, 65535.U, rxNextBytes)
        when(!keepLegal || (!io.rxData.bits.last && keep =/= 15.U) ||
            rxNextBytes > rxCapacity || rxNextBytes > maxFrameBytes.U) { rxFailed := true.B }
        when(rxNextBytes <= maxFrameBytes.U) {
            when(rxUpper || io.rxData.bits.last) {
                rxBuffer.write(rxCaptureIndex, Mux(rxUpper,
                    Cat(io.rxData.bits.data, rxLow), Cat(0.U(32.W), io.rxData.bits.data)))
                rxCaptureIndex := rxCaptureIndex + 1.U
            }.otherwise { rxLow := io.rxData.bits.data }
        }
        rxUpper := !rxUpper
        when(io.rxData.bits.last) { rxDataDone := true.B }
    }
    when(io.rxStatus.fire) {
        when(rxStatusIndex < 6.U) { statusWords(rxStatusIndex) := io.rxStatus.bits.data }
        when(io.rxStatus.bits.keep =/= 15.U || rxStatusIndex > 5.U ||
            (rxStatusIndex === 0.U && io.rxStatus.bits.data(31, 28) =/= 5.U) ||
            (io.rxStatus.bits.last =/= (rxStatusIndex === 5.U))) { rxFailed := true.B }
        when(io.rxStatus.bits.last) { rxStatusDone := true.B }
        when(rxStatusIndex < 6.U) { rxStatusIndex := rxStatusIndex + 1.U }
    }
    val rxIssued = RegInit(0.U(countBits.W))
    val rxReplied = RegInit(0.U(countBits.W))
    val rxStoreIndex = RegInit(0.U(indexBits.W))
    val rxPrefetchPending = WireDefault(false.B)
    val rxPrefetchOccupancy = WireDefault(0.U(3.W))
    val rxWord = Reg(UInt(64.W))
    // Driven by the validated control write below, without depending on the
    // write engine's request/response handshakes.
    val rxStopNow = WireDefault(false.B)
    // Internal observation points for focused packet-engine verification.
    val rxLinePhase = WireDefault(0.U(3.W))
    val rxLineReadPending = WireDefault(false.B)
    val rxLineAssemblyWords = WireDefault(0.U(4.W))
    val rxLineOwners = WireDefault(0.U(rxLineEntries.W))
    val rxLineOwnerCount = WireDefault(0.U(log2Ceil(rxLineEntries + 1).W))
    val rxLineScalarHeld = WireDefault(false.B)
    val rxLineOfferHeld = WireDefault(false.B)
    if (rxLineWrites) {
        val line = io.rxLine.get
        val localTagBits = math.max(1, log2Ceil(rxLineEntries))
        val prefix :: prefixDrain :: body :: lineDrain :: tail :: finalDrain :: abortDrain :: Nil = Enum(7)
        val phase = RegInit(prefix)
        val fetchIdle :: fetchReturn :: scalarOffer :: lineReady :: lineOffer :: Nil = Enum(5)
        val fetchState = RegInit(fetchIdle)
        // Cursor includes the terminal word count, which can be one beyond RAM.
        val cursor = RegInit(0.U(countBits.W))
        val lane = RegInit(0.U(3.W))
        val assembly = Reg(UInt(512.W))
        val readPending = RegInit(false.B)
        val scalarHeld = RegInit(false.B)
        val lineHeld = RegInit(false.B)
        val offerTag = Reg(UInt(localTagBits.W))
        val live = RegInit(VecInit(Seq.fill(rxLineEntries)(false.B)))
        rxLinePhase := phase
        rxLineReadPending := readPending
        rxLineAssemblyWords := Mux(fetchState === lineReady || fetchState === lineOffer, 8.U, lane)
        rxLineOwners := live.asUInt
        rxLineOwnerCount := PopCount(live)
        rxLineScalarHeld := scalarHeld
        rxLineOfferHeld := lineHeld
        val free = VecInit(live.map(v => !v)).asUInt
        val hasFree = free.orR
        val freeTag = PriorityEncoder(free)
        val writing = rxState === rxLoad
        val address = rxAddress + (cursor << 3)
        val remaining = rxBytes - (cursor << 3)
        val scalarPhase = phase === prefix || phase === tail
        val scalarEmpty = rxIssued === rxReplied
        val linesEmpty = !live.asUInt.orR
        rx.response.ready := writing
        line.response.ready := writing
        val scalarError = rx.response.fire && rx.response.bits.error
        val lineError = line.response.fire && line.response.bits.error
        val abort = rxFailed || rxStopNow || scalarError || lineError
        val readIssue = writing && !abort && fetchState === fetchIdle &&
            ((phase === prefix && remaining =/= 0.U && address(5, 0) =/= 0.U) ||
                (phase === body && remaining >= 64.U) ||
                (phase === tail && remaining =/= 0.U))
        val readData = rxBuffer.read((cursor + lane)(indexBits - 1, 0), readIssue)
        readPending := readIssue
        rxPrefetchPending := readPending
        when(readIssue) { fetchState := fetchReturn }
        when(readPending && !abort) {
            assert(fetchState === fetchReturn)
            when(scalarPhase) {
                rxWord := readData
                fetchState := scalarOffer
            }.otherwise {
                // Exactly one line payload register, shared by every local tag.
                // A constant lane splice avoids a separate 512-bit payload bank.
                for (i <- 0 until 8) {
                    when(lane === i.U) {
                        val parts = (0 until 8).reverse.map { j =>
                            if (j == i) readData else assembly(64 * j + 63, 64 * j)
                        }
                        assembly := Cat(parts)
                    }
                }
                when(lane === 7.U) { fetchState := lineReady }
                    .otherwise { lane := lane + 1.U; fetchState := fetchIdle }
            }
        }
        rx.request.valid := writing && fetchState === scalarOffer &&
            rxIssued - rxReplied < memoryCredits.U && (!abort || scalarHeld)
        rx.request.bits.address := address
        rx.request.bits.write := true.B
        rx.request.bits.size := 3.U
        rx.request.bits.data := rxWord
        rx.request.bits.byteEnable := Mux(remaining >= 8.U, 255.U,
            ((1.U(9.W) << remaining(2, 0)) - 1.U)(7, 0))
        when(rx.request.valid && !rx.request.ready) { scalarHeld := true.B }
        when(rx.request.fire) {
            rxIssued := rxIssued + 1.U
            scalarHeld := false.B
            cursor := cursor + 1.U
            fetchState := fetchIdle
            when(remaining <= 8.U) {
                phase := Mux(phase === prefix, prefixDrain, finalDrain)
            }
        }
        when(rx.response.fire) {
            assert(rxReplied < rxIssued || rx.request.fire)
            rxReplied := rxReplied + 1.U
            when(rx.response.bits.error) { rxFailed := true.B }
        }
        when(writing && !abort && fetchState === lineReady && hasFree) {
            offerTag := freeTag
            fetchState := lineOffer
        }
        line.request.valid := writing && fetchState === lineOffer && (!abort || lineHeld)
        line.request.bits.tag := offerTag
        line.request.bits.address := address
        line.request.bits.data := assembly
        line.request.bits.write := true.B
        when(line.request.valid && !line.request.ready) { lineHeld := true.B }
        when(line.request.fire) {
            assert(!live(offerTag))
            assert(address(5, 0) === 0.U && remaining >= 64.U)
            assert(address >= ramBase.U && (address +& 64.U) <= (ramBase + ramBytes).U)
            live(offerTag) := true.B
            lineHeld := false.B
            cursor := cursor + 8.U
            lane := 0.U
            fetchState := fetchIdle
        }
        when(line.response.fire) {
            assert(line.response.bits.tag < rxLineEntries.U)
            assert(live(line.response.bits.tag))
            live(line.response.bits.tag) := false.B
            when(line.response.bits.error) { rxFailed := true.B }
        }
        // ACK barriers separate the scalar and line routes. No dependency on
        // accepting another request is introduced into response consumption.
        when(writing && !abort && fetchState === fetchIdle) {
            when(phase === prefix && address(5, 0) === 0.U) { phase := prefixDrain }
            when(phase === prefixDrain && scalarEmpty) {
                phase := Mux((cursor << 3) >= rxBytes, finalDrain, body)
            }
            when(phase === body && remaining < 64.U) { phase := lineDrain }
            when(phase === lineDrain && linesEmpty) {
                phase := Mux((cursor << 3) >= rxBytes, finalDrain, tail)
            }
        }
        when(writing && abort) {
            phase := abortDrain
            // An old held offer is the only new work permitted after failure.
            // A RAM return or partial assembly has no external owner.
            when(!(scalarHeld && !rx.request.fire) && !(lineHeld && !line.request.fire)) {
                fetchState := fetchIdle
                lane := 0.U
            }
        }
        when(writing && (phase === finalDrain || phase === abortDrain) &&
            scalarEmpty && linesEmpty && !readPending && fetchState === fetchIdle &&
            !scalarHeld && !lineHeld && !rx.request.valid && !line.request.valid) {
            rxState := rxIdle
            rxDone := true.B
        }
        when(rxState === rxCollect && rxDataDone && rxStatusDone) {
            val frameBad = rxFailed || rxStopNow || rxBytes === 0.U ||
                statusWords(5)(15, 0) =/= rxBytes || !statusWords(3)(6) ||
                statusWords(3)(7) || statusWords(3)(8)
            when(frameBad) { rxState := rxIdle; rxDone := true.B; rxFailed := true.B }
                .otherwise {
                    assert(scalarEmpty && linesEmpty && !readPending && !scalarHeld && !lineHeld)
                    rxState := rxLoad
                    phase := prefix
                    fetchState := fetchIdle
                    cursor := 0.U
                    lane := 0.U
                }
        }
        assert(!scalarHeld || rx.request.valid)
        assert(!lineHeld || line.request.valid)
        assert(!readPending || writing)
        assert(!line.request.valid || (scalarEmpty && phase =/= prefix && phase =/= tail))
        assert(!rx.request.valid || linesEmpty)
        assert(PopCount(live) <= rxLineEntries.U)
        when(rxState === rxIdle || rxState === rxCollect) {
            assert(linesEmpty && scalarEmpty && !scalarHeld && !lineHeld && !readPending)
        }
        // Check payload/tag retention without synthesizing a second line-data
        // register: the only producer updates above are disabled while offered.
        when(lineHeld) { assert(fetchState === lineOffer && !readIssue) }
        when(scalarHeld) { assert(fetchState === scalarOffer && !readIssue) }
    } else if (!rxWritePrefetch) {
        val rxRead = rxBuffer.read(rxStoreIndex, rxState === rxLoad && !rxFailed)
        val rxRemaining = rxBytes - (rxStoreIndex << 3)
        val rxMask = Mux(rxRemaining >= 8.U, 255.U,
            ((1.U(9.W) << rxRemaining(2, 0)) - 1.U)(7, 0))
        rx.request.valid := rxState === rxOffer && rxIssued - rxReplied < memoryCredits.U
        rx.request.bits.address := rxAddress + (rxStoreIndex << 3)
        rx.request.bits.write := true.B
        rx.request.bits.size := 3.U
        rx.request.bits.data := rxWord
        rx.request.bits.byteEnable := rxMask
        rx.response.ready := rxState =/= rxIdle && rxState =/= rxCollect
        when(rx.response.fire) {
            rxReplied := rxReplied + 1.U
            when(rx.response.bits.error) { rxFailed := true.B }
        }
        when(rxState === rxCollect && rxDataDone && rxStatusDone) {
            val frameBad = rxFailed || rxBytes === 0.U || statusWords(5)(15, 0) =/= rxBytes ||
                !statusWords(3)(6) || statusWords(3)(7) || statusWords(3)(8)
            when(frameBad) { rxState := rxIdle; rxDone := true.B; rxFailed := true.B }
                .otherwise { rxState := rxLoad }
        }
        when(rxState === rxLoad) { rxState := Mux(rxFailed, rxDrain, rxWait) }
        when(rxState === rxWait) { rxWord := rxRead; rxState := Mux(rxFailed, rxDrain, rxOffer) }
        when(rx.request.fire) {
            rxIssued := rxIssued + 1.U
            when(rxFailed || rxRemaining <= 8.U) { rxState := rxDrain }
                .otherwise { rxStoreIndex := rxStoreIndex + 1.U; rxState := rxLoad }
        }
        when(rxState === rxDrain && rxIssued === rxReplied) { rxState := rxIdle; rxDone := true.B }
    } else {
        val rxRemaining = rxBytes - (rxStoreIndex << 3)
        val rxMask = Mux(rxRemaining >= 8.U, 255.U,
            ((1.U(9.W) << rxRemaining(2, 0)) - 1.U)(7, 0))
        rx.request.bits.address := rxAddress + (rxStoreIndex << 3)
        rx.request.bits.write := true.B
        rx.request.bits.size := 3.U
        rx.request.bits.byteEnable := rxMask
        // The synchronous read return owns a reserved queue entry. Never rely
        // on current downstream ready to make room for a next-cycle return.
        val storing = rxState === rxLoad || rxState === rxOffer
        val fetched = RegInit(0.U(countBits.W))
        val readPending = RegInit(false.B)
        val offerHeld = RegInit(false.B)
        val prefetched = withReset(reset.asBool || !storing) {
            Module(new Queue(UInt(64.W), 4, pipe = true, flow = false))
        }
        rxPrefetchOccupancy := prefetched.io.count
        val wordCount = (rxBytes +& 7.U) >> 3
        val readIssue = storing && !rxFailed && fetched < wordCount &&
            prefetched.io.count +& readPending.asUInt < 4.U
        val readData = rxBuffer.read(fetched(indexBits - 1, 0), readIssue)
        rxPrefetchPending := readPending
        readPending := readIssue
        when(readIssue) { fetched := fetched + 1.U }
        when(!storing) { fetched := 0.U; readPending := false.B }
        prefetched.io.enq.valid := readPending && storing
        prefetched.io.enq.bits := readData
        assert(!prefetched.io.enq.valid || prefetched.io.enq.ready)
        when(storing) {
            assert(prefetched.io.count +& readPending.asUInt <= 4.U)
            assert(fetched >= rxIssued)
            assert(fetched - rxIssued === prefetched.io.count +& readPending.asUInt)
        }
        // An offered word is irrevocable even when STOP/error arrives while
        // the scalar arbiter or memory holds ready low. Other prefetched words
        // are local only and may be discarded on entry to rxDrain.
        rx.request.valid := rxState === rxOffer && prefetched.io.deq.valid &&
            rxIssued - rxReplied < memoryCredits.U && (!rxFailed || offerHeld)
        rx.request.bits.data := prefetched.io.deq.bits
        prefetched.io.deq.ready := rx.request.fire
        when(rx.request.valid && !rx.request.ready) { offerHeld := true.B }
        when(rx.request.fire || !storing) { offerHeld := false.B }
        when(rxState === rxLoad) { rxState := Mux(rxFailed, rxDrain, rxOffer) }
        when(rxState === rxOffer && rxFailed && !offerHeld) { rxState := rxDrain }
        assert(!offerHeld || rx.request.valid)
        rx.response.ready := rxState =/= rxIdle && rxState =/= rxCollect
        when(rx.response.fire) {
            rxReplied := rxReplied + 1.U
            when(rx.response.bits.error) { rxFailed := true.B }
        }
        when(rxState === rxCollect && rxDataDone && rxStatusDone) {
            val frameBad = rxFailed || rxBytes === 0.U || statusWords(5)(15, 0) =/= rxBytes ||
                !statusWords(3)(6) || statusWords(3)(7) || statusWords(3)(8)
            when(frameBad) { rxState := rxIdle; rxDone := true.B; rxFailed := true.B }
                .otherwise { rxState := rxLoad }
        }
        when(rx.request.fire) {
            rxIssued := rxIssued + 1.U
            when(rxFailed || rxRemaining <= 8.U) { rxState := rxDrain }
                .otherwise { rxStoreIndex := rxStoreIndex + 1.U; rxState := rxOffer }
        }
        when(rxState === rxDrain && rxIssued === rxReplied) { rxState := rxIdle; rxDone := true.B }
    }

    // Register ABI V1. Full-width accesses only; descriptor mutation while active
    // and completion overwrite are rejected. W1C acknowledgements precede starts.
    val replies = Module(new Queue(new RegisterResponse, 2, pipe = false, flow = false))
    val r = io.control.request.bits
    val offset = r.address - base.U
    // Additive ABI: 0x90 RX_STOP=1; 0x98 bit 0 advertises safe RX stop.
    // Accepted memory requests are NEVER cancelled. A partly captured frame is
    // drained to both stream boundaries, then discarded without new DDR writes.
    val rxStop = offset === 144.U
    val known = Seq(0, 8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128, 136,
        144, 152, 160, 168, 176, 184, 192, 200, 208, 216)
        .map(n => offset === n.U).reduce(_ || _)
    val txWrite = offset === 16.U || offset === 24.U || offset === 32.U
    val txQueueKnown = txQueue.map(_.io.known).getOrElse(false.B)
    val txQueueAllowed = txQueue.map(_.io.allowed).getOrElse(false.B)
    val rxWrite = offset === 48.U || offset === 56.U || offset === 64.U
    val queueWrite = offset === 160.U || offset === 168.U || offset === 176.U ||
        offset === 184.U || offset === 216.U
    val queueEmpty = !rxBusy && !rxDone && !queueActive && ownedCount === 0.U
    val overlapsOwned = (0 until rxSlots).map { i =>
        slotOwned(i) && postAddress < (queuedAddress(i) +& queuedCapacity(i)) &&
            queuedAddress(i) < (postAddress +& postCapacity)
    }.reduce(_ || _)
    val writable = offset === 8.U || txWrite || rxWrite || rxStop || queueWrite || txQueueKnown
    val legal = r.address >= base.U && r.address < (base + 256).U(65.W) && (known || txQueueKnown) &&
        r.size === 3.U && r.byteEnable === 255.U &&
        (!r.write || (writable && (!txWrite || (!txBusy && !txQueueEnabled)) && (!rxWrite || (!rxBusy && !queueEnabled)) &&
            !(offset === 32.U && r.data(0) && txDone && !r.data(1)) &&
            !(offset === 64.U && r.data(0) && rxDone && !r.data(1)) &&
            (!rxStop || r.data === 1.U) &&
            (offset =/= 176.U || (r.data === 1.U && queueEnabled && !queueStopped &&
                ownedCount < rxSlots.U && !overlapsOwned && descriptorLegal(postAddress, postCapacity))) &&
            (offset =/= 184.U || (r.data <= 1.U && queueEmpty)) &&
            (offset =/= 216.U || (r.data === 1.U && queueEnabled && completedCount =/= 0.U)) &&
            (!txQueueKnown || txQueueAllowed)))
    rxStopNow := io.control.request.fire && legal && r.write && rxStop
    io.control.request.ready := replies.io.enq.ready
    replies.io.enq.valid := io.control.request.valid
    replies.io.enq.bits.error := !legal
    replies.io.enq.bits.data := Mux(legal && !r.write, MuxLookup(offset, 0.U(64.W))(Seq(
        0.U -> "h56444d4100010001".U(64.W), 8.U -> irqEnable,
        16.U -> txAddress, 24.U -> txLength, 40.U -> Cat(txFailed, txDone, txBusy),
        48.U -> rxAddress, 56.U -> rxCapacity, 72.U -> Cat(rxFailed, rxDone, rxBusy),
        80.U -> rxBytes, 136.U -> maxFrameBytes.U, 152.U -> ((BigInt(postedTxSlots) << 24) | (memoryCredits << 16) | (rxSlots << 8) |
            (if (postedTxSlots > 0) 7 else 3)).U,
        160.U -> postAddress, 168.U -> postCapacity, 184.U -> queueEnabled,
        192.U -> (pendingCount | (completedCount << 8) | (queueActive.asUInt << 16) |
            (queueStopped.asUInt << 17)),
        200.U -> Mux(completedCount =/= 0.U, queuedAddress(completionIndex), 0.U),
        208.U -> Mux(completedCount =/= 0.U, completedMetadata(completionIndex), 0.U)
    ) ++ Seq(224, 232, 240, 248).map(n => n.U -> txQueue.map(_.io.readData).getOrElse(0.U)) ++ (0 until 6).map(i => (88 + i * 8).U -> statusWords(i))), 0.U)
    io.control.response <> replies.io.deq
    txQueue.foreach { q =>
        q.io.offset := offset(7, 0); q.io.data := r.data; q.io.accessWrite := r.write
        q.io.write := io.control.request.fire && legal && r.write && q.io.known
        q.io.engineIdle := !txBusy && !txDone
        q.io.engineDone := txDone && !txBusy
        q.io.engineFailed := txFailed; q.io.engineBytes := Mux(txFailed, 0.U, txLength(15, 0))
        when(q.io.consumeDone) { txDone := false.B; txFailed := false.B }
        when(q.io.launch.valid) {
            txAddress := q.io.launch.bits.address; txLength := q.io.launch.bits.length
            txWordCount := roundedTxWords(q.io.launch.bits.length)
            txState := txFill; txDone := false.B; txFailed := false.B
            txSent := 0.U; txReceived := 0.U; txLocked := false.B; txBytes := 0.U
        }
    }

    def descriptorLegal(address: UInt, length: UInt): Bool = {
        val rounded = (length +& 7.U) & ~7.U(65.W)
        address(2, 0) === 0.U && address >= ramBase.U(65.W) && length =/= 0.U &&
            length <= maxFrameBytes.U && (address +& rounded) <= (ramBase + ramBytes).U(66.W)
    }
    when(io.control.request.fire && legal && r.write) {
        switch(offset) {
            is(160.U) { postAddress := r.data }
            is(168.U) { postCapacity := r.data }
            is(176.U) {
                slotOwned(postIndex) := true.B
                queuedAddressWords(postIndex) := postAddress(queuedAddressBits - 1, 3)
                queuedCapacity(postIndex) := postCapacity(queuedCapacityBits - 1, 0)
                postIndex := (if (rxSlots == 1) 0.U else postIndex + 1.U)
                post := true.B
            }
            is(184.U) {
                queueEnabled := r.data(0)
                queueStopped := false.B
                postIndex := 0.U; launchIndex := 0.U; completionIndex := 0.U
            }
            is(216.U) {
                pop := true.B; slotOwned(completionIndex) := false.B
                completionIndex := (if (rxSlots == 1) 0.U else completionIndex + 1.U)
            }
            is(144.U) {
                when(queueEnabled) { queueStopped := true.B }
                when(rxBusy) {
                    rxFailed := true.B
                    when(rxState === rxCollect && rxBytes === 0.U && rxStatusIndex === 0.U &&
                        !rxDataDone && !rxStatusDone && !io.rxData.valid && !io.rxStatus.valid) {
                        rxState := rxIdle; rxDone := true.B
                    }.elsewhen((!rxLineWrites).B && (rxState === rxLoad || rxState === rxWait ||
                        (rxState === rxOffer && (!rx.request.valid || rx.request.fire)))) {
                        rxState := rxDrain
                    }
                    // A valid held rxOffer retains payload; a credit-blocked (invalid)
                    // offer has no external owner and may stop without issuing it.
                    // rxCollect with any received/offered beat retains ready and
                    // drains data + status; rxFailed suppresses the memory phase.
                }
            }
            is(8.U) { irqEnable := r.data(1, 0) }
            is(16.U) { txAddress := r.data }
            is(24.U) { txLength := r.data }
            is(48.U) { rxAddress := r.data }
            is(56.U) { rxCapacity := r.data }
            is(32.U) {
                when(r.data(1)) { txDone := false.B; txFailed := false.B }
                when(r.data(0)) {
                    val valid = descriptorLegal(txAddress, txLength)
                    when(valid) { txWordCount := roundedTxWords(txLength) }
                    txState := Mux(valid, txFill, txIdle); txDone := !valid; txFailed := !valid
                    txSent := 0.U; txReceived := 0.U; txLocked := false.B
                }
            }
            is(64.U) {
                when(r.data(1)) { rxDone := false.B; rxFailed := false.B }
                when(r.data(0)) {
                    val valid = descriptorLegal(rxAddress, rxCapacity)
                    rxState := Mux(valid, rxCollect, rxIdle); rxDone := !valid; rxFailed := !valid
                    rxBytes := 0.U; rxDataDone := false.B; rxStatusDone := false.B
                    rxStatusIndex := 0.U; rxUpper := false.B; rxCaptureIndex := 0.U
                    rxIssued := 0.U; rxReplied := 0.U
                    rxStoreIndex := 0.U
                    statusWords.foreach(_ := 0.U)
                }
            }
        }
    }
    // Publish completion only after both frame streams and all accepted DDR
    // responses have retired. Firmware's consume fence precedes payload reads.
    when(queueEnabled && queueActive && rxDone && !rxBusy) {
        completedMetadata(activeIndex) := rxBytes(15, 0) | (rxFailed.asUInt << 16)
        complete := true.B
        queueActive := false.B
        rxDone := false.B
        rxFailed := false.B
    }
    // Stop wins over launches in the very cycle its MMIO write is accepted.
    val stopping = queueStopped || (io.control.request.fire && legal && r.write && rxStop)
    when(queueEnabled && !queueActive && !rxBusy && !rxDone && pendingCount =/= 0.U) {
        consumePending := true.B
        launchIndex := (if (rxSlots == 1) 0.U else launchIndex + 1.U)
        when(stopping) {
            completedMetadata(launchIndex) := (1 << 16).U // cancelled before capture
            complete := true.B
        }.otherwise {
            rxAddress := queuedAddress(launchIndex)
            rxCapacity := queuedCapacity(launchIndex)
            activeIndex := launchIndex
            queueActive := true.B
            rxState := rxCollect
            rxDone := false.B; rxFailed := false.B
            rxBytes := 0.U; rxDataDone := false.B; rxStatusDone := false.B
            rxStatusIndex := 0.U; rxUpper := false.B; rxCaptureIndex := 0.U
            rxIssued := 0.U; rxReplied := 0.U; rxStoreIndex := 0.U
            statusWords.foreach(_ := 0.U)
        }
    }
    assert(ownedCount === PopCount(slotOwned))
    assert(ownedCount <= rxSlots.U)
    assert(ownedCount === pendingCount +& completedCount + queueActive.asUInt)
    assert(!queueActive || queueEnabled)
    assert(txSent >= txReceived && txSent - txReceived <= memoryCredits.U)
    assert(rxIssued >= rxReplied && rxIssued - rxReplied <= memoryCredits.U)
}
