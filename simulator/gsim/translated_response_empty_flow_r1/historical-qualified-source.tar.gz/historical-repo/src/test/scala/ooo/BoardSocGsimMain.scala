package ooo

import _root_.circt.stage.ChiselStage
import chisel3._
import chisel3.util._
import chisel3.util.experimental.BoringUtils
import java.nio.file.{Files, Paths}
import soc.core.ooo.{BoardSocConfig, BoardSocTop, DdrBridgeConfig, CoherentCacheConcurrency, CacheTagConfig, FpgaStorageConfig, FpgaNextConfig}

/** Avoid exposing a Vec at the GSIM top boundary (the pinned generator needs scalar accessors). */
class BoardSocGsim(externalDdr: Boolean = false, clockHz: Int = 40000000,
    timingProfile: String = BoardSocConfig.timingProfile, uartBaud: Int = 1500000,
    dataCacheWays: Int = BoardSocConfig.dataCacheWays,
    issueWidth: Int = BoardSocConfig.issueWidth, instructionPrefetch: Boolean = true,
    isaProfile: String = BoardSocConfig.isaProfile,
    ddrMemoryBytes: BigInt = BoardSocConfig.ddrBytes, frontendProbes: Boolean = false,
    instructionLineCacheLines: Int = 8, backendProbes: Boolean = false, dataCacheLines: Int = 32,
    ddrBridge: DdrBridgeConfig = BoardSocConfig.ddrBridge,
    cacheConcurrency: CoherentCacheConcurrency = CoherentCacheConcurrency(),
    loadIssueForwarding: Option[Boolean] = None,
    tagConfig: CacheTagConfig = CacheTagConfig.FullWidth,
    identityDataFlow: Boolean = false,
    fpgaStorage: FpgaStorageConfig = FpgaStorageConfig.Registers,
    virtualRamLoadPrecheck: Boolean = false,
    floatingPointResources: soc.core.ooo.FloatingPointResourceConfig = soc.core.ooo.FloatingPointResourceConfig.baseline,
    independentFetchPayloadCapture: Boolean = false,
    ownerLocalIssueReady: Boolean = false, sharedFetchPmpRelations: Boolean = false,
    bankedInstructionData: Boolean = false, dmaLineTransfers: Boolean = false,
    dmaLineYieldCycles: Int = 0, dmaLineEntries: Int = 1,
    precheckedDataRequestFlow: Boolean = false, physicalLoadIngressFlow: Boolean = false,
    loadOrderOlderRetire: Boolean = false, fetchPreviousPacket: Boolean = false,
    preparedStoreLookahead: Boolean = false, dataTranslationEntries: Int = 8,
    translatedResponseEmptyFlow: Boolean = false, postedStoreMerge: Boolean = false,
    lineageProfile: Option[soc.core.ooo.FpgaNextConfig] = None,
    postedPrefetchHeadOffer: Boolean = false, canonicalVirtualStoreOverlap: Boolean = false, memoryProofFrontier: Boolean = false,
    frozenStoreProofTransport: Boolean = false, pendingVirtualStoreProof: Boolean = false,
    pendingVirtualStoreProofSlots: Int = 1,
    pendingStoreEarlyLoadCredits: Int = 1,
    boundHeadStoreOverlap: Boolean = false,
    pendingReadyStoreBypass: Boolean = false,
    taggedStoreReturns: Boolean = false,
    backendCapacity: soc.core.ooo.BackendCapacityConfig = soc.core.ooo.BackendCapacityConfig(),
    postedPreparationPriority: Boolean = false, lineTransferDispatchFlow: Boolean = false,
    dataTlbWriteReadReuse: Boolean = false, translationHitFlow: Boolean = false,
    configurationCheck: Option[FpgaNextConfig] = None, registeredPmpRegions: Boolean = false, publishedPmpChanges: Boolean = false,
    registeredPendingStoreQuery: Boolean = false, alignedFetchPermissionStage: Boolean = false,
    registeredCanonicalStoreEvent: Boolean = false, sharedLane1OwnerMatch: Boolean = false,
    directRank1MemorySourceIds: Boolean = false, directRegisteredExecutionOperands: Boolean = false,
    sharedCanonicalStoreOwnerMatch: Boolean = false, eagerFetchPrefixSelect: Boolean = false,
    predecodedHeadDrain: Boolean = false, retirementIntent: Boolean = false,
    fetchAddressBeforePmp: Boolean = false, queuedHeadSelection: Boolean = false,
    alignedNextLinePmp: Boolean = false, registerProbeLookup: Boolean = false,
    localAddressRanges: Boolean = false, memoryPreparationHeadMask: Boolean = false,
    directRank0MemorySourceIds: Boolean = false, fetchReadyDataClear: Boolean = false,
    retirementSlotIdentity: Boolean = false, localCacheReadSelection: Boolean = false,
    fetchAcceptedPrefixValidation: Boolean = false, alignedFetchSinglePage: Boolean = false,
    factorCheckedNextAllowed: Boolean = false, localTaggedResponseReady: Boolean = false,
    postedYoungerLoadSealDeferral: Boolean = false,
    heldAluIssueForwarding: Boolean = false,
    residentMemoryPayloadReuse: Boolean = false,
    registeredLoadResultReady: Boolean = false,
    frozenStoreCheckedFlow: Boolean = false,
    pendingReadyStoreQuery: Boolean = false, registeredHomeRequestBoundary: Boolean = false,
    val proofBankControlDecoupling: Boolean = false, val projectedRequestHead: Boolean = false,
    val factorPreparedStorePool: Boolean = false, combinedTimingR1Audit: Boolean = false,
    val sharedTwoWordFetchPmp: Boolean = false, val disjointEvictionStoreOverlap: Boolean = false, val registerNextLineDecision: Boolean = false, val registeredMemoryPreparationDescriptor: Boolean = false, val backendNaturalAlignedPmp: Boolean = false,
    ethernetRxOverride: Option[soc.ip.dma.NetworkDmaConfig] = None) extends Module {
    require(configurationCheck.nonEmpty &&
        pendingReadyStoreQuery == configurationCheck.get.coreParams.pendingReadyStoreQuery &&
        registeredHomeRequestBoundary == configurationCheck.get.coreParams.registeredHomeRequestBoundary,
        "ready-store query argument must match actual constructor configuration")
    require(configurationCheck.nonEmpty, "matching board requires explicit actual configuration checks")
    HeldAluIntegrationActualAudit.requireArgument(configurationCheck.get, heldAluIssueForwarding)
    ResidentMemoryIntegrationActualAudit.requireArgument(configurationCheck.get, residentMemoryPayloadReuse)
    require(registeredLoadResultReady == configurationCheck.get.coreParams.registeredLoadResultReady &&
        frozenStoreCheckedFlow == configurationCheck.get.coreParams.frozenStoreCheckedFlow,
        "both timing-closure arguments must match the complete actual board configuration")
    require(postedYoungerLoadSealDeferral == configurationCheck.get.coreParams.postedYoungerLoadSealDeferral &&
        frozenStoreProofTransport == configurationCheck.get.coreParams.frozenStoreProofTransport &&
        pendingVirtualStoreProof == configurationCheck.get.coreParams.pendingVirtualStoreProof &&
        registeredPendingStoreQuery == configurationCheck.get.coreParams.registeredPendingStoreQuery &&
        alignedFetchPermissionStage == configurationCheck.get.coreParams.alignedFetchPermissionStage &&
        registeredCanonicalStoreEvent == configurationCheck.get.coreParams.registeredCanonicalStoreEvent &&
        sharedLane1OwnerMatch == configurationCheck.get.coreParams.sharedLane1OwnerMatch &&
        directRank1MemorySourceIds == configurationCheck.get.coreParams.directRank1MemorySourceIds &&
        memoryPreparationHeadMask == configurationCheck.get.coreParams.memoryPreparationHeadMask &&
        directRank0MemorySourceIds == configurationCheck.get.coreParams.directRank0MemorySourceIds &&
        fetchReadyDataClear == configurationCheck.get.coreParams.fetchReadyDataClear &&
        retirementSlotIdentity == configurationCheck.get.coreParams.retirementSlotIdentity &&
        localCacheReadSelection == configurationCheck.get.localCacheReadSelection &&
        fetchAcceptedPrefixValidation == configurationCheck.get.coreParams.fetchAcceptedPrefixValidation &&
        alignedFetchSinglePage == configurationCheck.get.coreParams.alignedFetchSinglePage &&
        factorCheckedNextAllowed == configurationCheck.get.coreParams.factorCheckedNextAllowed &&
        localTaggedResponseReady == configurationCheck.get.coreParams.localTaggedResponseReady &&
        directRegisteredExecutionOperands == configurationCheck.get.coreParams.directRegisteredExecutionOperands &&
        sharedCanonicalStoreOwnerMatch == configurationCheck.get.coreParams.sharedCanonicalStoreOwnerMatch &&
        eagerFetchPrefixSelect == configurationCheck.get.coreParams.eagerFetchPrefixSelect &&
        predecodedHeadDrain == configurationCheck.get.coreParams.predecodedHeadDrain &&
        retirementIntent == configurationCheck.get.coreParams.retirementIntent &&
        fetchAddressBeforePmp == configurationCheck.get.coreParams.fetchAddressBeforePmp &&
        queuedHeadSelection == configurationCheck.get.coreParams.queuedHeadSelection &&
        alignedNextLinePmp == configurationCheck.get.coreParams.alignedNextLinePmp &&
        registerProbeLookup == configurationCheck.get.registerProbeLookup &&
        localAddressRanges == configurationCheck.get.localAddressRanges &&
        pendingVirtualStoreProofSlots == configurationCheck.get.coreParams.pendingVirtualStoreProofSlots &&
        pendingStoreEarlyLoadCredits == configurationCheck.get.coreParams.pendingStoreEarlyLoadCredits &&
        boundHeadStoreOverlap == configurationCheck.get.coreParams.boundHeadStoreOverlap &&
        pendingReadyStoreBypass == configurationCheck.get.coreParams.pendingReadyStoreBypass &&
        taggedStoreReturns == configurationCheck.get.coreParams.taggedStoreReturns,
        "pending-store proof switches differ from the actual matching-board configuration")
    require(publishedPmpChanges == configurationCheck.get.coreParams.publishedPmpChanges,
        "PMP raw change flag differs from the actual matching-board configuration")
    require(registeredPmpRegions == configurationCheck.get.coreParams.registeredPmpRegions,
        "PMP publication flag differs from the actual matching-board configuration")
    private val board = Module(new MatchingManagedBoard(configurationCheck.get, jtagRamDownload = true,
        sharedTwoWordFetchPmp = sharedTwoWordFetchPmp, disjointEvictionStoreOverlap = disjointEvictionStoreOverlap,
        proofBankControlDecoupling = proofBankControlDecoupling,
        projectedRequestHead = projectedRequestHead, factorPreparedStorePool = factorPreparedStorePool,
        registeredMemoryPreparationDescriptor = registeredMemoryPreparationDescriptor, backendNaturalAlignedPmp = backendNaturalAlignedPmp,
        registerNextLineDecision = registerNextLineDecision,
        combinedTimingR1Audit = combinedTimingR1Audit, ethernetRxOverride = ethernetRxOverride))
    def observedPlatform: soc.core.ooo.MachinePlatform = board.platform
    val service = IO(chiselTypeOf(board.service))
    service <> board.service
    configurationCheck.foreach { expected =>
        // Read retained constructor products from the instances that are being emitted.
        def unique[T](instance: AnyRef, kind: Class[T]): T = {
            val fields = scala.collection.mutable.ArrayBuffer.empty[java.lang.reflect.Field]
            var declaring: Class[_] = instance.getClass
            while (declaring != null) {
                fields ++= declaring.getDeclaredFields.filter(f =>
                    !java.lang.reflect.Modifier.isStatic(f.getModifiers) && f.getType == kind)
                declaring = declaring.getSuperclass
            }
            require(fields.size == 1, "actual constructor field is absent or ambiguous: " + kind.getName)
            fields.head.setAccessible(true)
            kind.cast(fields.head.get(instance))
        }
        require(unique(board.platform, classOf[DdrBridgeConfig]) == expected.ddr,
            "actual platform DDR bridge parameters differ from the single board profile")
        require(unique(board.platform.privateCache.get, classOf[CoherentCacheConcurrency]) == expected.cache,
            "actual cache concurrency differs from the single board profile")
        require(board.platform.core.core.core.p == expected.coreParams,
            "actual GSIM core parameters differ from the single board profile")
        require(board.platform.core.core.core.backend.lsu.slots.size == expected.lsuEntries,
            "actual GSIM LSU owner count differs from the single board profile")
        require(expected.lsuEntries != 4 || timingProfile == BoardSocConfig.memoryCapacityProfile,
            "four-slot occupancy requires the actual memory-capacity timing profile")
        require(board.platform.dma.io.line.nonEmpty == expected.dmaLineTransfers,
            "actual GSIM DMA line port presence differs from the single board profile")
        require(dataCacheLines == expected.dataCacheLines && dataCacheWays == expected.cacheWays &&
            instructionLineCacheLines == expected.instructionCacheLines && ddrMemoryBytes == expected.ddrBytes &&
            dataTranslationEntries == expected.dataTranslationEntries && dmaLineEntries == expected.dmaLineEntries &&
            ddrBridge == expected.ddr && cacheConcurrency == expected.cache && tagConfig == expected.tags,
            "actual GSIM constructor geometry differs from the single board profile")
    }
    // A test-only, passive scalar view of this exact Board instance. No inputs,
    // queues or control paths are inserted by the composition fixture.
    val lineage = lineageProfile.map { profile =>
        val result = IO(Output(new PostedBoardTrace(profile.coreParams)))
        PostedBoardProbes.connect(result, board, profile)
        result
    }
    val io = IO(new Bundle {
        val uartRx = Input(Bool())
        val uartTx = Output(Bool())
        val program = Input(chiselTypeOf(board.io.program.get))
        val ramProgram = Input(new Bundle {
            val write = Bool()
            val index = UInt(17.W)
            val data = UInt(64.W)
        })
        val ddrReady = Input(Bool())
        val ddrAxi = if (externalDdr) Some(new soc.ip.axi.Axi4MemoryPort(32, ddrBridge.axiIdWidth)) else None
        val trap = Output(chiselTypeOf(board.io.trap.get))
        val commit0 = Output(Bool())
        val commit0Pc = Output(UInt(64.W))
        val commit1 = Output(Bool())
        val commit1Pc = Output(UInt(64.W))
        val fetchPc = Output(UInt(64.W))
        val cacheProfile = Output(new soc.core.ooo.CoherentCacheProfile)
        val headProfile = Output(new soc.core.ooo.HeadProfile)
    })
    board.io.uartRx := io.uartRx
    board.io.program.get := io.program
    board.io.ramProgram.foreach(_ := io.ramProgram)
    if (externalDdr) {
        board.io.ddrReady.get := io.ddrReady
        io.ddrAxi.get <> board.io.ddrAxi.get
    }
    io.uartTx := board.io.uartTx
    io.trap := board.io.trap.get
    io.commit0 := board.io.commit.get(0).valid
    io.commit0Pc := board.io.commit.get(0).bits.pc
    io.commit1 := board.io.commit.get(1).valid
    io.commit1Pc := board.io.commit.get(1).bits.pc
    io.fetchPc := board.io.fetchPc.get
    io.cacheProfile := board.io.cacheProfile.get
    io.headProfile := board.io.headProfile.get

    // Capacity experiment only: scalar leaf taps preserve production interfaces and avoid
    // dynamic BoringUtils vector reads in the pinned generator. Old ledgers stay two-slot.
    val memoryLiveSlots = IO(Output(UInt(4.W)))
    if (timingProfile == BoardSocConfig.memoryCapacityProfile) {
        val slots = board.platform.core.core.core.backend.lsu.slots
        memoryLiveSlots := PopCount(slots.map(slot => BoringUtils.bore(slot.io.busy)))
    } else {
        memoryLiveSlots := 0.U
    }

    // Passive performance accounting only. Each field comes from an existing
    // production event; this adds no flow-control or architectural state.
    val dataPrefetchOriginEvents = IO(Output(UInt(6.W)))
    dataPrefetchOriginEvents := 0.U
    if (backendProbes && board.platform.privateCache.nonEmpty) {
        board.platform.privateCache.get match {
            case cache: soc.core.ooo.NonBlockingCoherentLineCache =>
                val observed = cache.observationStorePrefetch
                val candidate = BoringUtils.bore(observed.candidate)
                val candidateStore = BoringUtils.bore(observed.candidateStore)
                val allocated = BoringUtils.bore(observed.allocated)
                val allocatedStore = BoringUtils.bore(observed.allocatedStore)
                val useful = BoringUtils.bore(observed.useful)
                val usefulStore = BoringUtils.bore(observed.usefulStore)
                dataPrefetchOriginEvents := VecInit(Seq(
                    candidate && !candidateStore, candidate && candidateStore,
                    allocated && !allocatedStore, allocated && allocatedStore,
                    useful && !usefulStore, useful && usefulStore)).asUInt
            case _ =>
        }
    }
    val dataPrefetchEvents = IO(Output(UInt(11.W)))
    if (backendProbes && board.platform.privateCache.nonEmpty) {
        val cache = board.platform.privateCache.get
        dataPrefetchEvents := Cat(BoringUtils.bore(cache.io.prefetch.releaseOwners),
            BoringUtils.bore(cache.io.prefetch.missOwners), VecInit(Seq(
                BoringUtils.bore(cache.io.prefetch.candidate),
                BoringUtils.bore(cache.io.prefetch.allocated),
                BoringUtils.bore(cache.io.prefetch.useful),
                BoringUtils.bore(cache.io.prefetch.error),
                BoringUtils.bore(cache.io.prefetchBusy))).asUInt)
    } else { dataPrefetchEvents := 0.U }

    // Optional passive owner-qualified backend probes. Index and 64-bit tag remain separate.
    val backendEvents = IO(Output(UInt(48.W)))
    val backendHeadTag = IO(Output(UInt(64.W)))
    val backendHeadIndex = IO(Output(UInt(8.W)))
    val backendQueueHeadIndex = IO(Output(UInt(8.W)))
    val backendQueueHeadTag = IO(Output(UInt(64.W)))
    val backendRequestTag = IO(Output(UInt(64.W)))
    val backendRequestIndex = IO(Output(UInt(8.W)))
    val backendStartTag = IO(Output(UInt(64.W)))
    val backendStartIndex = IO(Output(UInt(8.W)))
    val backendCompleteTag = IO(Output(UInt(64.W)))
    val backendCompleteIndex = IO(Output(UInt(8.W)))
    val backendSlot0Tag = IO(Output(UInt(64.W)))
    val backendSlot1Tag = IO(Output(UInt(64.W)))
    // Upper-pair passive ABI leaves the historical lower pair unchanged.
    val backendSlot2Tag = IO(Output(UInt(64.W)))
    val backendSlot3Tag = IO(Output(UInt(64.W)))
    val backendSlotIndicesHi = IO(Output(UInt(16.W)))
    val backendSlotStateHi = IO(Output(UInt(16.W)))
    val backendSlotCount = IO(Output(UInt(8.W)))
    val backendSlotIndices = IO(Output(UInt(16.W)))
    val backendSlotState = IO(Output(UInt(16.W)))
    val backendReturnSlot = IO(Output(UInt(2.W)))
    val backendFifoCount = IO(Output(UInt(4.W)))
    val backendStoreCause = IO(Output(UInt(3.W)))
    val cpuTagged = if (taggedStoreReturns) Some(IO(Output(new TaggedBoardTrace))) else None
    val backendReset = IO(Output(Bool()))
    // Full scalar fingerprints for passive physical data-path ownership, never dynamic vector taps.
    val dataPathEvents = IO(Output(UInt(48.W)))
    // Optional bandwidth-experiment provenance. The legacy dataPath ABI stays
    // intact; these taps include the authorization fields it predates.
    val cpuFlowEvents = IO(Output(UInt(8.W)))
    val cpuFlowIngressAuth = IO(Output(UInt(64.W)))
    val cpuFlowCheckedAuth = IO(Output(UInt(64.W)))
    val cpuFlowCheckedAddress = IO(Output(UInt(64.W)))
    val cpuFlowCheckedData = IO(Output(UInt(64.W)))
    val cpuFlowCheckedHeadAuth = IO(Output(UInt(64.W)))
    val cpuFlowPhysicalAuth = IO(Output(UInt(64.W)))
    val dataPathCounts = IO(Output(UInt(64.W)))
    val dataPathRequest0Address = IO(Output(UInt(64.W)))
    val dataPathRequest0Data = IO(Output(UInt(64.W)))
    val dataPathRequest0Meta = IO(Output(UInt(64.W)))
    val dataPathRequest1Address = IO(Output(UInt(64.W)))
    val dataPathRequest1Data = IO(Output(UInt(64.W)))
    val dataPathRequest1Meta = IO(Output(UInt(64.W)))
    val dataPathRequest2Address = IO(Output(UInt(64.W)))
    val dataPathRequest2Data = IO(Output(UInt(64.W)))
    val dataPathRequest2Meta = IO(Output(UInt(64.W)))
    val dataPathRequest3Address = IO(Output(UInt(64.W)))
    val dataPathRequest3Data = IO(Output(UInt(64.W)))
    val dataPathRequest3Meta = IO(Output(UInt(64.W)))
    val dataPathRequest4Address = IO(Output(UInt(64.W)))
    val dataPathRequest4Data = IO(Output(UInt(64.W)))
    val dataPathRequest4Meta = IO(Output(UInt(64.W)))
    val dataPathRequest5Address = IO(Output(UInt(64.W)))
    val dataPathRequest5Data = IO(Output(UInt(64.W)))
    val dataPathRequest5Meta = IO(Output(UInt(64.W)))
    val dataPathRequest6Address = IO(Output(UInt(64.W)))
    val dataPathRequest6Data = IO(Output(UInt(64.W)))
    val dataPathRequest6Meta = IO(Output(UInt(64.W)))
    val dataPathRequest7Address = IO(Output(UInt(64.W)))
    val dataPathRequest7Data = IO(Output(UInt(64.W)))
    val dataPathRequest7Meta = IO(Output(UInt(64.W)))
    val dataPathRequest8Address = IO(Output(UInt(64.W)))
    val dataPathRequest8Data = IO(Output(UInt(64.W)))
    val dataPathRequest8Meta = IO(Output(UInt(64.W)))
    val dataPathRequest9Address = IO(Output(UInt(64.W)))
    val dataPathRequest9Data = IO(Output(UInt(64.W)))
    val dataPathRequest9Meta = IO(Output(UInt(64.W)))
    val dataPathReply0Data = IO(Output(UInt(64.W)))
    val dataPathReply0Flags = IO(Output(UInt(64.W)))
    val dataPathReply1Data = IO(Output(UInt(64.W)))
    val dataPathReply1Flags = IO(Output(UInt(64.W)))
    val dataPathReply2Data = IO(Output(UInt(64.W)))
    val dataPathReply2Flags = IO(Output(UInt(64.W)))
    val dataPathReply3Data = IO(Output(UInt(64.W)))
    val dataPathReply3Flags = IO(Output(UInt(64.W)))
    val dataPathReply4Data = IO(Output(UInt(64.W)))
    val dataPathReply4Flags = IO(Output(UInt(64.W)))
    // Passive bandwidth diagnostics. Bits are independent event/blocked predicates,
    // not mutually exclusive causal buckets. No production ready/valid is changed.
    val cpuBandwidthEvents = IO(Output(UInt(24.W)))
    val cpuTranslationHitPass = IO(Output(Bool()))
    val cpuAuthorizedHandoff = IO(Output(Bool()))
    val cpuIndependentAdmission = IO(Output(UInt(3.W)))
    // Test-only passive view of existing valid-guarded prefetch qualification wires.
    val cpuSupplyPrefetch = IO(Output(new soc.core.ooo.CheckedStorePrefetchObservation(
        log2Ceil(cacheConcurrency.readMshrs))))
    cpuSupplyPrefetch := 0.U.asTypeOf(cpuSupplyPrefetch)
    cpuBandwidthEvents := 0.U
    cpuTranslationHitPass := false.B
    cpuAuthorizedHandoff := false.B
    cpuIndependentAdmission := 0.U
    backendReset := reset.asBool
    backendSlotCount := BoardSocConfig.timingParams(timingProfile, issueWidth).memoryEntries.U
    if (backendProbes) {
        require(frontendProbes && issueWidth == 2)
        val b = board.platform.core.core.core.backend
        val l = b.lsu
        cpuAuthorizedHandoff := BoringUtils.bore(l.observationCanonicalHandoff)
        board.platform.privateCache.get match {
            case cache: soc.core.ooo.NonBlockingCoherentLineCache =>
                cpuIndependentAdmission := BoringUtils.bore(cache.observationIndependentDemand)
                cpuSupplyPrefetch := BoringUtils.bore(cache.observationStorePrefetch)
            case _ =>
        }
        val q = b.observationRequests.get
        val stores = b.observationStores.get
        require(Set(2, 4).contains(l.slots.size), "backend probes require two or four LSU owners")
        def tap[T <: Data](signal: T): T = BoringUtils.bore(signal)
        val h = tap(b.head)
        // Static scalar taps avoid dynamic-array output aliases in the pinned GSIM graph pass.
        def atHead(bits: Seq[Bool]): Bool = Mux1H(bits.zipWithIndex.map { case (bit, i) => (h === i.U) -> bit })
        val memoryReady1 = atHead((0 until b.p.robEntries).map(i => tap(b.ownerReady.get.io.ready1(i))))
        val memoryReady2 = atHead((0 until b.p.robEntries).map(i => tap(b.ownerReady.get.io.ready2(i))))
        val store = tap(b.headRequest.store)
        val atomic = tap(b.headRequest.atomic)
        val saved = atHead((0 until b.p.robEntries).map(i => tap(b.storePrepared(i))))
        val choiceHead = tap(b.memoryChoice.valid) && tap(b.memoryChoice.index) === h
        val headToken = b.ledger.io.headSystem.get.headToken
        backendHeadTag := tap(headToken.tag)
        backendHeadIndex := tap(headToken.index)
        backendQueueHeadTag := tap(b.headRenamed.token.tag)
        backendQueueHeadIndex := tap(b.headRenamed.token.index)
        backendRequestTag := tap(l.io.requestOwner.bits.tag)
        backendRequestIndex := tap(l.io.requestOwner.bits.index)
        backendStartTag := tap(l.io.start.bits.token.tag)
        backendStartIndex := tap(l.io.start.bits.token.index)
        backendCompleteTag := tap(l.io.complete.bits.token.tag)
        backendCompleteIndex := tap(l.io.complete.bits.token.index)
        backendSlot0Tag := tap(l.io.owner(0).tag)
        backendSlot1Tag := tap(l.io.owner(1).tag)
        backendSlotIndices := Cat(tap(l.io.owner(1).index).pad(8), tap(l.io.owner(0).index).pad(8))
        def slotPairState(first: Int): UInt = Cat(0.U(6.W),
            tap(l.io.cancel(first + 1)), tap(l.io.cancel(first)),
            tap(l.parallel(first + 1)), tap(l.parallel(first)),
            tap(l.io.phase(first + 1)), tap(l.io.phase(first)),
            tap(l.io.live(first + 1)), tap(l.io.live(first)))
        backendSlotState := slotPairState(0)
        if (l.slots.size == 4) {
            backendSlot2Tag := tap(l.io.owner(2).tag)
            backendSlot3Tag := tap(l.io.owner(3).tag)
            backendSlotIndicesHi := Cat(tap(l.io.owner(3).index).pad(8), tap(l.io.owner(2).index).pad(8))
            backendSlotStateHi := slotPairState(2)
        } else {
            backendSlot2Tag := 0.U; backendSlot3Tag := 0.U
            backendSlotIndicesHi := 0.U; backendSlotStateHi := 0.U
        }
        backendReturnSlot := tap(l.owners.io.deq.bits)
        backendFifoCount := tap(q.io.count)
        backendStoreCause := tap(stores.io.requestStallCause)
        val adapter = board.platform.core.observationTranslation.get
        cpuTranslationHitPass := BoringUtils.bore(adapter.translationHitPass)
        val responses = board.platform.core.observationResponses.get
        cpuTagged.foreach { o =>
            require(l.slots.size == 4 && b.p.storeBufferEntries == 2 && b.p.tagBits == 64)
            require(b.p.cpuReturnConfig.get.handleBits == 3 && b.p.cpuReturnConfig.get.handleCount == 7)
            def privateData[T <: Data](instance: AnyRef, name: String): T = {
                val fields = instance.getClass.getDeclaredFields.filter(_.getName == name)
                require(fields.size == 1, "tagged board observation field absent/ambiguous: " + name)
                fields.head.setAccessible(true)
                fields.head.get(instance).asInstanceOf[T]
            }
            def request(out: TaggedBoardRequest, in: DecoupledIO[soc.core.ooo.DataRequest]): Unit = {
                out.valid := tap(in.valid); out.ready := tap(in.ready)
                out.handle := tap(in.bits.returnHandle.get)
                out.address := tap(in.bits.address); out.data := tap(in.bits.data)
                out.write := tap(in.bits.write); out.size := tap(in.bits.size)
                out.ordinary := !tap(in.bits.atomic) && !tap(in.bits.uncached)
            }
            def response(out: TaggedBoardResponse, in: DecoupledIO[soc.core.ooo.DataResponse]): Unit = {
                out.valid := tap(in.valid); out.ready := tap(in.ready)
                out.handle := tap(in.bits.returnHandle.get); out.data := tap(in.bits.data)
                out.flags := Cat(tap(in.bits.pageFault), tap(in.bits.error))
            }
            o.startValid := (tap(l.io.start.valid) && tap(l.io.start.ready)); o.startSlot := tap(l.chosen)
            o.startVa := tap(l.io.start.bits.address); o.startPa := tap(l.io.start.bits.physicalAddress)
            o.startData := tap(l.io.start.bits.data); o.startSize := tap(l.io.start.bits.size)
            o.startFlags := Cat(tap(l.io.start.bits.frozenStoreProof.get.valid),
                tap(l.io.start.bits.precheckedLoad), tap(l.io.start.bits.virtualized),
                tap(l.io.start.bits.atomic), tap(l.io.start.bits.store))
            request(o.queued, q.io.enq)
            request(o.physical, adapter.io.physical.request)
            response(o.physicalReply, adapter.io.physical.response)
            response(o.integerReply, l.io.memory.response)
            request(o.sbRequest, stores.io.memory.request)
            response(o.sbReply, stores.io.memory.response)
            o.sbEnqueue := tap(stores.anyEnqueue); o.sbFast := tap(stores.fastEnqueue)
            o.sbSlot := tap(stores.tail); o.sbOriginHandle := tap(stores.request.bits.returnHandle.get)
            o.sbAddress := Mux(tap(stores.fastEnqueue), tap(stores.io.fastStore.bits.address), tap(stores.request.bits.address))
            o.sbData := Mux(tap(stores.fastEnqueue), tap(stores.io.fastStore.bits.data), tap(stores.request.bits.data))
            o.sbSize := Mux(tap(stores.fastEnqueue), tap(stores.io.fastStore.bits.size), tap(stores.request.bits.size))
            o.sbLocal := (tap(stores.request.valid) && tap(stores.request.ready)) && (tap(stores.buffered) || tap(stores.forward))
            o.sbLocalWrite := tap(stores.request.bits.write)
            o.sbDrainReply := tap(stores.dequeue)
            o.fpEpoch := tap(b.fpMemoryEpoch)
            o.fpIndex := tap(b.systemOwner.index); o.fpTag := tap(b.systemOwner.tag)
            request(o.backendRequest, b.io.memory.request); response(o.backendReply, b.io.memory.response)
            o.fpComplete := tap(b.fpMemoryEpoch) && (tap(b.systemComplete.valid) && tap(b.systemComplete.ready))
            o.fpCompleteIndex := tap(b.systemComplete.bits.token.index); o.fpCompleteTag := tap(b.systemComplete.bits.token.tag)
            o.fpTval := tap(b.systemComplete.bits.tval); o.fpException := tap(b.systemComplete.bits.exception)
            o.fpCause := tap(b.systemComplete.bits.cause)
            for ((out, i) <- o.slots.zipWithIndex) {
                val s = l.slots(i)
                out.live := tap(s.io.busy); out.index := tap(s.io.owner.index); out.tag := tap(s.io.owner.tag)
                out.cancel := tap(s.io.cancel); out.discard := tap(s.io.discarded)
                out.complete := (tap(s.io.complete.valid) && tap(s.io.complete.ready)); out.fastLoad := tap(s.io.fastLoadRetire)
                out.completeIndex := tap(s.io.complete.bits.token.index); out.completeTag := tap(s.io.complete.bits.token.tag)
                out.tval := tap(s.io.complete.bits.tval); out.exception := tap(s.io.complete.bits.exception)
                out.cause := tap(s.io.complete.bits.cause)
            }
            val cache = board.platform.privateCache.get.asInstanceOf[soc.core.ooo.NonBlockingCoherentLineCache]
            request(o.cache, cache.io.upstream.request); response(o.cacheReply, cache.io.upstream.response)
            def privateOption[T](name: String): T = {
                val fields = cache.getClass.getDeclaredFields.filter(_.getName == name)
                require(fields.size == 1, "tagged board option observation absent/ambiguous: " + name)
                fields.head.setAccessible(true)
                fields.head.get(cache).asInstanceOf[Option[T]].get
            }
            val rowHandles = privateOption[Vec[UInt]]("responseHandle")
            val rowKinds = privateOption[Vec[UInt]]("responseKind")
            o.cacheHandle0 := tap(rowHandles(0)); o.cacheHandle1 := tap(rowHandles(1))
            o.cacheKind0 := tap(rowKinds(0)); o.cacheKind1 := tap(rowKinds(1))
            o.cacheSelected := tap(privateData[UInt](cache, "responseSelected"))
            o.cacheOldestHit := tap(privateData[Bool](cache, "headHitAvailable"))
            o.cacheStoreWrite := tap(privateData[Bool](cache, "storeWrite"))
            o.cachePostedIntent := tap(privateData[Bool](cache, "postedIntent"))
        }


        val profile = BoardSocConfig.timingParams(timingProfile, issueWidth)
        require(profile.registeredMemoryAddress && profile.earlyRecoveryIssueBlock &&
            profile.registeredTranslationHeads && profile.registeredTranslatedResponses &&
            profile.registeredStoreResponseOwners && issueWidth == 2)
        val incomingQueue = adapter.virtualRequests.get
        val checkedQueue = adapter.checked.get
        val vm = board.platform.io.translationEvents.get
        cpuBandwidthEvents := VecInit(Seq(
            tap(vm.hit(1)), tap(vm.walk(1)), tap(vm.pteRead(1)), tap(vm.pteCacheHit(1)),
            tap(vm.hit(0)), tap(vm.walk(0)), tap(vm.pteRead(0)), !tap(vm.idle(1)),
            tap(adapter.incoming.valid) && !tap(adapter.incoming.ready),
            tap(adapter.waiting), tap(adapter.translated.io.deq.valid) && !tap(adapter.translated.io.deq.ready),
            tap(checkedQueue.deq.valid) && !tap(checkedQueue.deq.ready),
            tap(adapter.io.physical.request.valid) && !tap(adapter.io.physical.request.ready),
            tap(adapter.io.virtual.request.valid) && !tap(adapter.io.virtual.request.ready),
            tap(adapter.io.virtual.response.valid) && !tap(adapter.io.virtual.response.ready),
            tap(adapter.io.physical.request.valid) && tap(adapter.io.physical.request.ready),
            tap(adapter.io.physical.response.valid) && tap(adapter.io.physical.response.ready),
            tap(board.platform.privateCache.get.io.upstream.request.valid) &&
                !tap(board.platform.privateCache.get.io.upstream.request.ready),
            tap(board.platform.io.fetchWait), tap(l.io.start.valid) && !tap(l.io.start.ready),
            tap(vm.flush), tap(adapter.owners.io.enq.valid) && !tap(adapter.owners.io.enq.ready),
            tap(adapter.translated.io.enq.valid) && !tap(adapter.translated.io.enq.ready),
            tap(checkedQueue.enq.valid) && !tap(checkedQueue.enq.ready))).asUInt
        def requestMeta(r: soc.core.ooo.DataRequest): UInt = Cat(tap(r.uncached), tap(r.virtualized),
            tap(r.mask), tap(r.size), tap(r.atomicOp), tap(r.atomic), tap(r.write)).pad(64)
        def requestAuthorization(r: soc.core.ooo.DataRequest): UInt = Cat(tap(r.prefetchNextAllowed),
            tap(r.translationEpoch), tap(r.precheckedLoad), tap(r.uncached), tap(r.virtualized),
            tap(r.mask), tap(r.size), tap(r.atomicOp), tap(r.atomic), tap(r.write)).pad(64)
        cpuFlowEvents := VecInit(Seq(
            tap(incomingQueue.io.enq.valid) && tap(incomingQueue.io.enq.ready),
            tap(adapter.physicalIngressPass), tap(adapter.precheckedPass),
            tap(checkedQueue.enq.valid) && tap(checkedQueue.enq.ready), tap(adapter.identityPass),
            tap(incomingQueue.io.deq.valid) && tap(incomingQueue.io.deq.ready),
            tap(checkedQueue.enq.ready), tap(adapter.io.virtual.request.valid))).asUInt
        cpuFlowIngressAuth := requestAuthorization(adapter.io.virtual.request.bits)
        cpuFlowCheckedAuth := requestAuthorization(checkedQueue.enq.bits.request)
        cpuFlowCheckedAddress := tap(checkedQueue.enq.bits.request.address)
        cpuFlowCheckedData := tap(checkedQueue.enq.bits.request.data)
        cpuFlowCheckedHeadAuth := requestAuthorization(checkedQueue.deq.bits.request)
        cpuFlowPhysicalAuth := requestAuthorization(adapter.io.physical.request.bits)
        dataPathRequest0Address := tap(q.io.enq.bits.address)
        dataPathRequest0Data := tap(q.io.enq.bits.data)
        dataPathRequest0Meta := requestMeta(q.io.enq.bits)
        dataPathRequest1Address := tap(q.io.deq.bits.address)
        dataPathRequest1Data := tap(q.io.deq.bits.data)
        dataPathRequest1Meta := requestMeta(q.io.deq.bits)
        dataPathRequest2Address := tap(stores.io.fastStore.bits.address)
        dataPathRequest2Data := tap(stores.io.fastStore.bits.data)
        dataPathRequest2Meta := requestMeta(stores.io.fastStore.bits)
        dataPathRequest3Address := tap(stores.io.memory.request.bits.address)
        dataPathRequest3Data := tap(stores.io.memory.request.bits.data)
        dataPathRequest3Meta := requestMeta(stores.io.memory.request.bits)
        dataPathRequest4Address := tap(adapter.io.virtual.request.bits.address)
        dataPathRequest4Data := tap(adapter.io.virtual.request.bits.data)
        dataPathRequest4Meta := requestMeta(adapter.io.virtual.request.bits)
        dataPathRequest5Address := tap(adapter.incoming.bits.address)
        dataPathRequest5Data := tap(adapter.incoming.bits.data)
        dataPathRequest5Meta := requestMeta(adapter.incoming.bits)
        dataPathRequest6Address := tap(adapter.translated.io.enq.bits.request.address)
        dataPathRequest6Data := tap(adapter.translated.io.enq.bits.request.data)
        dataPathRequest6Meta := requestMeta(adapter.translated.io.enq.bits.request)
        dataPathRequest7Address := tap(adapter.translated.io.deq.bits.request.address)
        dataPathRequest7Data := tap(adapter.translated.io.deq.bits.request.data)
        dataPathRequest7Meta := requestMeta(adapter.translated.io.deq.bits.request)
        dataPathRequest8Address := tap(checkedQueue.deq.bits.request.address)
        dataPathRequest8Data := tap(checkedQueue.deq.bits.request.data)
        dataPathRequest8Meta := requestMeta(checkedQueue.deq.bits.request)
        dataPathRequest9Address := tap(adapter.io.physical.request.bits.address)
        dataPathRequest9Data := tap(adapter.io.physical.request.bits.data)
        dataPathRequest9Meta := requestMeta(adapter.io.physical.request.bits)
        dataPathReply0Data := tap(adapter.io.physical.response.bits.data)
        dataPathReply0Flags := Cat(tap(adapter.io.physical.response.bits.pageFault), tap(adapter.io.physical.response.bits.error)).pad(64)
        dataPathReply1Data := tap(adapter.io.virtual.response.bits.data)
        dataPathReply1Flags := Cat(tap(adapter.io.virtual.response.bits.pageFault), tap(adapter.io.virtual.response.bits.error)).pad(64)
        dataPathReply2Data := tap(responses.io.upstream.response.bits.data)
        dataPathReply2Flags := Cat(tap(responses.io.upstream.response.bits.pageFault), tap(responses.io.upstream.response.bits.error)).pad(64)
        dataPathReply3Data := tap(stores.io.memory.response.bits.data)
        dataPathReply3Flags := Cat(tap(stores.io.memory.response.bits.pageFault), tap(stores.io.memory.response.bits.error)).pad(64)
        dataPathReply4Data := tap(stores.io.upstream.response.bits.data)
        dataPathReply4Flags := Cat(tap(stores.io.upstream.response.bits.pageFault), tap(stores.io.upstream.response.bits.error)).pad(64)
        dataPathCounts := Cat(0.U(28.W), tap(responses.responses.count).pad(4),
            tap(adapter.owners.io.count).pad(4), tap(checkedQueue.count).pad(4),
            tap(adapter.translated.io.count).pad(4), tap(incomingQueue.io.count).pad(4),
            tap(stores.reads).pad(4), tap(stores.owners.io.count).pad(4),
            tap(stores.issued).pad(4), tap(stores.count).pad(4))
        // Exact selected-profile duplicate of reserveMemory with only issueAvailable removed.
        // The registered-address profile captures operands before this predicate. The equality
        // is checked by the host on every nonreset sample, including cycles outside the ROI.
        val reserveWithoutCapacity = !tap(b.interruptDrain) && !tap(b.reserveSystem) &&
            !tap(b.olderSystem) && !tap(b.fpMemoryEpoch) && !tap(b.contextMemoryEpoch) &&
            tap(b.memoryChoice.valid) &&
            tap(b.io.commitEnable) && !tap(b.ledger.io.recovering) &&
            (!tap(b.memoryEntry.request.atomic) || !tap(b.io.memoryBusy)) &&
            (tap(b.memoryChoice.index) === h || (tap(b.speculative) && !tap(b.blockedByStore)))
        val launchWithoutCapacity = reserveWithoutCapacity && !tap(b.earlyRecoveryIssueBlock) &&
            !tap(b.ledger.io.pendingException.valid)
        val younger = tap(b.memoryChoice.index) =/= h && !tap(b.memoryEntry.request.store) &&
            !tap(b.memoryEntry.request.atomic)
        val capacityCandidate = launchWithoutCapacity && younger && tap(l.noOtherSerial) &&
            (tap(l.io.parallel) || tap(l.othersIdle))
        dataPathEvents := VecInit(Seq(
            tap(stores.io.memory.request.valid) && tap(stores.io.memory.request.ready),
            tap(stores.io.memory.response.valid) && tap(stores.io.memory.response.ready),
            tap(stores.drainRequest), tap(stores.flowBufferedWrite), tap(stores.flowFastWrite),
            tap(stores.owners.io.deq.valid), tap(stores.owners.io.deq.bits),
            tap(stores.enqueue), tap(stores.io.forwarded), tap(stores.fastEnqueue),
            tap(b.fpMemoryEpoch) && tap(b.io.memory.request.valid) && tap(b.io.memory.request.ready),
            tap(b.fpMemoryEpoch) && tap(b.io.memory.response.valid) && tap(b.io.memory.response.ready),
            tap(adapter.io.virtual.request.valid) && tap(adapter.io.virtual.request.ready),
            tap(adapter.incoming.valid) && tap(adapter.incoming.ready),
            tap(adapter.io.translation.request.valid) && tap(adapter.io.translation.request.ready),
            tap(adapter.io.translation.response.valid) && tap(adapter.io.translation.response.ready),
            tap(adapter.translated.io.enq.valid) && tap(adapter.translated.io.enq.ready),
            tap(adapter.translated.io.deq.valid) && tap(adapter.translated.io.deq.ready),
            tap(checkedQueue.deq.valid) && tap(checkedQueue.deq.ready),
            tap(adapter.io.physical.request.valid) && tap(adapter.io.physical.request.ready),
            tap(adapter.io.virtual.response.valid) && tap(adapter.io.virtual.response.ready),
            tap(adapter.io.physical.response.valid) && tap(adapter.io.physical.response.ready),
            tap(responses.responses.enq.valid) && tap(responses.responses.enq.ready),
            tap(responses.responses.deq.valid) && tap(responses.responses.deq.ready),
            tap(adapter.waiting), tap(adapter.incoming.bits.virtualized), tap(adapter.physicalFault),
            tap(adapter.owners.io.deq.bits.fault), tap(stores.ackValid),
            tap(adapter.fault), tap(adapter.translated.io.deq.bits.pageFault), tap(adapter.physicalPageFault),
            capacityCandidate, capacityCandidate && !tap(l.available),
            tap(l.io.start.valid) && tap(l.io.start.ready) && younger,
            ((reserveWithoutCapacity && tap(l.io.issueAvailable)) === tap(b.reserveMemory)) &&
                ((launchWithoutCapacity && tap(l.io.issueAvailable)) === tap(l.io.start.valid)),
            tap(b.ordinaryRam), tap(b.memoryEntry.request.store), tap(b.memoryEntry.request.atomic), younger,
            tap(b.fpMemoryEpoch), tap(adapter.translated.io.enq.bits.pageFault),
            tap(adapter.translated.io.enq.bits.accessFault)
        )).asUInt
        backendEvents := VecInit(Seq(
            saved || (memoryReady1 && (!(store || atomic) || memoryReady2)),
            atHead(b.memoryCandidates.map(c => tap(c.valid))), choiceHead,
            tap(l.io.start.valid) && tap(l.io.start.ready),
            tap(b.directStoreFire), tap(l.available), tap(l.noOtherSerial), tap(l.othersIdle),
            tap(l.io.parallel), tap(l.io.issueAvailable), tap(l.io.start.ready),
            tap(b.memoryChoice.valid), tap(b.interruptDrain), tap(b.reserveSystem), tap(b.olderSystem),
            tap(b.fpMemoryEpoch), tap(b.io.commitEnable), tap(b.ledger.io.recovering),
            atomic && tap(b.io.memoryBusy), tap(l.io.start.valid),
            tap(q.io.enq.valid), tap(q.io.enq.ready), tap(q.io.deq.valid), tap(q.io.deq.ready),
            tap(l.io.memory.response.valid), tap(l.io.memory.response.ready),
            tap(l.io.complete.valid), tap(l.io.complete.ready), tap(l.owners.io.deq.valid),
            atHead((0 until b.p.robEntries).map(i => tap(b.eligible(i)))), tap(b.headRequest.system), tap(b.headRequest.mulDiv), store, atomic, saved,
            tap(l.io.fastLoadRetire), tap(l.io.forwarded), tap(stores.buffered), tap(stores.forward),
            tap(stores.local), tap(stores.ackValid), tap(l.io.requestOwner.valid),
            tap(l.io.start.bits.forward.valid), tap(stores.io.fastStore.valid) && tap(stores.io.fastStore.ready)
        )).asUInt
    } else {
        backendSlot2Tag := 0.U; backendSlot3Tag := 0.U
        backendSlotIndicesHi := 0.U; backendSlotStateHi := 0.U
        cpuFlowEvents := 0.U; cpuFlowIngressAuth := 0.U; cpuFlowCheckedAuth := 0.U
        cpuFlowCheckedAddress := 0.U; cpuFlowCheckedData := 0.U
        cpuFlowCheckedHeadAuth := 0.U; cpuFlowPhysicalAuth := 0.U
        dataPathReply4Data := 0.U; dataPathReply4Flags := 0.U
        dataPathEvents := 0.U; dataPathCounts := 0.U
        dataPathRequest0Address := 0.U
        dataPathRequest0Data := 0.U
        dataPathRequest0Meta := 0.U
        dataPathRequest1Address := 0.U
        dataPathRequest1Data := 0.U
        dataPathRequest1Meta := 0.U
        dataPathRequest2Address := 0.U
        dataPathRequest2Data := 0.U
        dataPathRequest2Meta := 0.U
        dataPathRequest3Address := 0.U
        dataPathRequest3Data := 0.U
        dataPathRequest3Meta := 0.U
        dataPathRequest4Address := 0.U
        dataPathRequest4Data := 0.U
        dataPathRequest4Meta := 0.U
        dataPathRequest5Address := 0.U
        dataPathRequest5Data := 0.U
        dataPathRequest5Meta := 0.U
        dataPathRequest6Address := 0.U
        dataPathRequest6Data := 0.U
        dataPathRequest6Meta := 0.U
        dataPathRequest7Address := 0.U
        dataPathRequest7Data := 0.U
        dataPathRequest7Meta := 0.U
        dataPathRequest8Address := 0.U
        dataPathRequest8Data := 0.U
        dataPathRequest8Meta := 0.U
        dataPathRequest9Address := 0.U
        dataPathRequest9Data := 0.U
        dataPathRequest9Meta := 0.U
        dataPathReply0Data := 0.U
        dataPathReply0Flags := 0.U
        dataPathReply1Data := 0.U
        dataPathReply1Flags := 0.U
        dataPathReply2Data := 0.U
        dataPathReply2Flags := 0.U
        dataPathReply3Data := 0.U
        dataPathReply3Flags := 0.U
        backendEvents := 0.U
        backendHeadTag := 0.U; backendHeadIndex := 0.U; backendQueueHeadTag := 0.U; backendQueueHeadIndex := 0.U
        backendRequestTag := 0.U; backendRequestIndex := 0.U
        backendStartTag := 0.U; backendStartIndex := 0.U
        backendCompleteTag := 0.U; backendCompleteIndex := 0.U
        backendSlot0Tag := 0.U; backendSlot1Tag := 0.U
        backendSlotIndices := 0.U; backendSlotState := 0.U; backendReturnSlot := 0.U
        backendFifoCount := 0.U; backendStoreCause := 0.U
    }

    // Test-only passive taps: no production IO or functional logic changes.
    val perfEvents = IO(Output(UInt(48.W)))
    val perfOccupancy = IO(Output(UInt(3.W)))
    val perfSupply = IO(Output(UInt(2.W)))
    val perfCapture = IO(Output(UInt(2.W)))
    val perfRename = IO(Output(UInt(2.W)))
    val perfDiscard = IO(Output(UInt(3.W)))
    val perfTranslationPhase = IO(Output(UInt(3.W)))
    val perfFetchGetSize = IO(Output(UInt(3.W)))
    val perfFetchGetAddress = IO(Output(UInt(64.W)))
    val perfCacheEvents = IO(Output(UInt(16.W)))
    val perfCacheState = IO(Output(UInt(3.W)))
    val perfCacheGetSource = IO(Output(UInt(8.W)))
    if (frontendProbes) {
        require(issueWidth == 2, "frontend probes currently describe two-wide production configuration")
        perfFetchGetSize := BoringUtils.bore(board.platform.io.activity.get.fetchGetSize)
        perfFetchGetAddress := BoringUtils.bore(board.platform.io.activity.get.fetchGetAddress)
        val cache = board.platform.instructionLineCache.get
        def cacheTap[T <: Data](signal: T): T = BoringUtils.bore(signal)
        val cacheAValid = cacheTap(cache.io.tl.a.valid)
        val cacheAReady = cacheTap(cache.io.tl.a.ready)
        perfCacheState := cacheTap(cache.perfState)
        perfCacheGetSource := cacheTap(cache.io.tl.a.bits.source)
        perfCacheEvents := VecInit(Seq(
            cacheTap(cache.perfAcceptedHit), cacheTap(cache.perfAcceptedMiss),
            cacheTap(cache.perfAcceptedFallback), cacheTap(cache.perfDemandRefillRequest),
            cacheTap(cache.perfDemandRefillComplete), cacheTap(cache.perfDemandRefillError),
            cacheTap(cache.perfDemandRefillInstall), cacheTap(cache.perfWaitingRefill),
            cacheTap(cache.perfFallbackActive), cacheTap(cache.perfRetryFallback),
            cacheTap(cache.perfWaitingPrefetch),
            cacheTap(cache.io.fetch.response.valid) && cacheTap(cache.io.fetch.response.ready),
            cacheTap(cache.io.fetch.request.valid) && cacheTap(cache.io.fetch.request.ready),
            cacheAValid && cacheAReady,
            cacheTap(cache.io.tl.d.valid) && cacheTap(cache.io.tl.d.ready),
            cacheAValid && !cacheAReady
        )).asUInt
        val c = board.platform.core.core.core
        val packet = c.fetchPacket.get
        val ledger = c.backend.ledger
        def tap[T <: Data](signal: T): T = BoringUtils.bore(signal)
        val occupancy = tap(packet.io.occupancy)
        val supply = VecInit(packet.io.supply.map(x => tap(x.valid)))
        val captured = VecInit(packet.io.captured.map(tap(_)))
        val consumed = VecInit(packet.io.consume.map(tap(_)))
        val allocate = VecInit(ledger.io.allocate.map(x => tap(x.valid)))
        val renamed = VecInit(ledger.io.renamed.map(x => tap(x.valid)))
        val pause = tap(packet.io.pause)
        val correction = tap(packet.wrongPath)
        val flush = tap(packet.io.flush.valid)
        val recovery = tap(ledger.recoveryCycle)
        val dispatch = tap(ledger.io.dispatchReady)
        val exhausted = tap(ledger.io.tagExhausted)
        val robFull = tap(ledger.io.occupancy) === ledger.p.robEntries.U
        val capacity0 = tap(ledger.faultCandidates.get.io.capacity)(0)
        val capacity1 = tap(ledger.faultCandidates.get.io.capacity)(1)
        val adapter = board.platform.fetchAdapter.get
        val virtualReq = tap(adapter.io.virtual.request.valid)
        val virtualReady = tap(adapter.io.virtual.request.ready)
        val virtualReply = tap(adapter.io.virtual.response.valid)
        val physicalReq = tap(adapter.io.physical.request.valid)
        val physicalReady = tap(adapter.io.physical.request.ready)
        val physicalReply = tap(adapter.io.physical.response.valid)
        val physicalWait = tap(adapter.io.physical.response.ready)
        val translate = tap(adapter.io.translation.response.ready)
        val translationReq = tap(adapter.io.translation.request.valid)
        val translationReady = tap(adapter.io.translation.request.ready)
        val translationReply = tap(adapter.io.translation.response.valid)
        val f = board.platform.frontend
        val supplyCount = PopCount(supply)
        val consumeCount = PopCount(consumed)
        perfOccupancy := occupancy
        perfSupply := supplyCount
        perfCapture := PopCount(captured)
        perfRename := PopCount(renamed)
        perfDiscard := Mux(correction || flush, occupancy - consumeCount, 0.U)
        // Exclusive observed adapter phases; phase 5 means no exposed predicate matched.
        perfTranslationPhase := Mux(virtualReply, 4.U, Mux(virtualReady, 0.U, Mux(translate, 1.U,
            Mux(physicalReq, 2.U, Mux(physicalWait, 3.U, 5.U)))))
        val events = Seq(
            pause, correction, flush, recovery, tap(ledger.io.recovering),
            allocate(0) && !dispatch, allocate(0) && recovery,
            allocate(0) && exhausted, allocate(0) && robFull,
            allocate(0) && !capacity0,
            allocate(1) && renamed(0) && !capacity1,
            occupancy === 4.U && consumeCount > 0.U && supply(0) && !pause && !correction && !flush,
            occupancy === 3.U && consumeCount > 0.U && supplyCount === 2.U && !pause && !correction && !flush,
            supply(0) && !captured(0), supply(0) && !supply(1),
            virtualReq && virtualReady, virtualReq && !virtualReady, virtualReply,
            physicalReq && physicalReady, physicalReq && !physicalReady,
            physicalReply && physicalWait,
            translationReq && translationReady, translationReply && translate,
            translationReq && translationReady && tap(adapter.io.translation.request.bits.mode) === 0.U,
            tap(f.io.pause), tap(f.io.invalidate), !tap(f.io.instruction0.valid),
            tap(c.backend.headTrapAccepted), tap(c.backend.headSystemAccepted),
            tap(c.backend.ordinaryLocalRedirectAccepted) && tap(c.backend.localInclusive),
            tap(c.backend.ordinaryLocalRedirectAccepted) && !tap(c.backend.localInclusive),
            tap(c.backend.externalWins) && tap(ledger.io.recoveryAccepted),
            tap(board.platform.io.activity.get.fetchGetFire),
            allocate(0), renamed(0), tap(ledger.io.freeCount) === 0.U,
            tap(f.io.enable), translate && !translationReply,
            physicalWait && !physicalReply,
            !supply(0) && occupancy === 0.U && !pause && !correction && !flush,
            virtualReply && virtualReq && !virtualReady,
            virtualReq && virtualReady && (tap(adapter.io.vmState.satp)(63, 60) === 0.U ||
                tap(adapter.io.privilege) === 3.U)
        )
        perfEvents := VecInit(events).asUInt
    } else {
        perfEvents := 0.U
        perfOccupancy := 0.U
        perfSupply := 0.U
        perfCapture := 0.U
        perfRename := 0.U
        perfDiscard := 0.U
        perfTranslationPhase := 0.U
        perfFetchGetSize := 0.U
        perfFetchGetAddress := 0.U
        perfCacheEvents := 0.U
        perfCacheState := 0.U
        perfCacheGetSource := 0.U
    }
}

/** Same memory sizes, address map, latency and compact core as the FPGA board. */
object BoardSocGsimMain extends App {
    val virtualRamLoadPrecheck = args.contains("--virtual-ram-load-precheck")
    val boardArgs = args.filterNot(_ == "--virtual-ram-load-precheck")
    val (memoryArgs, mixedMemory) = soc.core.ooo.MixedMemoryConfig.parseArgs(boardArgs)
    val (storageArgs, fpgaStorage) = FpgaStorageConfig.parseArgs(memoryArgs)
    val identityDataFlow = storageArgs.contains("--identity-data-flow")
    val tagConfig = CacheTagConfig(compact = args.contains("--compact-tags"))
    val cli = storageArgs.filterNot(arg => arg == "--compact-tags" || arg == "--identity-data-flow")
    require(cli.length >= 1 && cli.length <= 19,
        "usage: BoardSocGsimMain output-directory [ddr] [clock-hz] " +
            "[baseline|early-issue|queued-memory|registered-response|registered-replay|staged-fabric|staged-control] " +
            "[uart-baud] [cache-ways] " +
            "[issue-width:2|4] [instruction-prefetch:0|1] [isa:rv64imac|rv64imafc|rv64gc] [ddr-memory-bytes] [frontend-probes:0|1] [instruction-line-cache-lines] [backend-probes:0|1] [data-cache-lines] [ddr-read-slots:1|2|4|8] [ddr-burst-beats:8|16] [read-mshrs:1|2|4] [cache-response-entries] [load-issue-forwarding:0|1] [--compact-tags] [--identity-data-flow] [--unordered-ddr-responses] [--data-next-line-prefetch] [--ddr-write-slots=N] [--cache-writebacks=N] [--overlap-writeback-refill] [--banked-rob] [--shared-store-reads] [--reconstruct-issue-token-index] [--shared-memory-address-state] [--lvt-prf] [--virtual-ram-load-precheck]")
    require(cli.lift(18).forall(Set("0", "1").contains), "load issue forwarding must be 0 or 1")
    require(cli.lift(12).forall(Set("0", "1").contains), "backend-probes must be 0 or 1")
    require(cli.lift(10).forall(Set("0", "1").contains), "frontend-probes must be 0 or 1")
    require(cli.lift(7).forall(Set("0", "1").contains), "instruction-prefetch must be 0 or 1")
    val output = Paths.get(cli.head)
    Files.createDirectories(output)
    ChiselStage.emitCHIRRTLFile(new BoardSocGsim(cli.lift(1).contains("ddr"),
        cli.lift(2).map(_.toInt).getOrElse(40000000),
        cli.lift(3).getOrElse(BoardSocConfig.timingProfile),
        cli.lift(4).map(_.toInt).getOrElse(1500000),
        cli.lift(5).map(_.toInt).getOrElse(BoardSocConfig.dataCacheWays),
        cli.lift(6).map(_.toInt).getOrElse(BoardSocConfig.issueWidth),
        !cli.lift(7).contains("0"),
        cli.lift(8).getOrElse(BoardSocConfig.isaProfile),
        cli.lift(9).map(BigInt(_)).getOrElse(BoardSocConfig.ddrBytes),
        cli.lift(10).contains("1"),
        cli.lift(11).map(_.toInt).getOrElse(8),
        cli.lift(12).contains("1"),
        cli.lift(13).map(_.toInt).getOrElse(32),
        mixedMemory.ddr(DdrBridgeConfig(maxOutstanding = cli.lift(14).map(_.toInt).getOrElse(1),
            maxBurstBeats = cli.lift(15).map(_.toInt).getOrElse(16))),
        mixedMemory.cache(CoherentCacheConcurrency(readMshrs = cli.lift(16).map(_.toInt).getOrElse(1),
            responseEntries = cli.lift(17).map(_.toInt).getOrElse(2))),
        loadIssueForwarding = cli.lift(18).map(_ == "1"),
        tagConfig = tagConfig, identityDataFlow = identityDataFlow, fpgaStorage = fpgaStorage,
        virtualRamLoadPrecheck = virtualRamLoadPrecheck),
        Array("--target-dir", output.toString))
}
